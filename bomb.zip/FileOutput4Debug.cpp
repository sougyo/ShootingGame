#include "FileOutput4Debug.h"

using namespace debug::fileio;

FileOutput4Debug::FileOutput4Debug(std::string fileName) : out(fileName.c_str()) {
}

void FileOutput4Debug::writeln(std::string str) {
	out << str << std::endl;
}

void FileOutput4Debug::write(std::string str) {
	out << str;
}