#ifndef ___FILEOUTPUT4DEBUG_H
#define ___FILEOUTPUT4DEBUG_H

#include <string>
#include <fstream>

namespace debug {
	namespace fileio {
		class FileOutput4Debug;
	}
}

class debug::fileio::FileOutput4Debug {
public:
	FileOutput4Debug(std::string fileName);
	void writeln(std::string str);
	void write(std::string str);
private:
	std::ofstream out;
};

#endif	/* ___FILEOUTPUT4DEBUG_H */