#ifndef ___FONT_FACTORY_H
#define ___FONT_FACTORY_H

#include <d3d9.h>
#include <d3dx9.h>

#include "Font.h"

namespace font {
	class FontFactory;
}

class font::FontFactory {
private:
	FontFactory();
public:
	~FontFactory();

	void initialize(LPDIRECT3DDEVICE9& device);
	void initialize(HDC hdc);
	Font* createFont(int x1, int y1, int x2, int y2, int height, int width, bool isLeft);
	Font* createFont(void);

	static FontFactory* getInstance(void)	{ return singleton; }

private:
	LPDIRECT3DDEVICE9	device;
	HDC hdc;

	static FontFactory* singleton;

};

#endif /* ___FONT_FACTORY_H */