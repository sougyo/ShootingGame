#ifndef ___GAMEFWD_H
#define ___GAMEFWD_H

namespace gameutil {
	class MovePattern;
	class Moveable;
}

namespace gamesystem {
	class Fighter;
}

namespace itemutil {
	class ItemElement;
	class ItemKind;
}

#endif // ___GAMEFWD_H