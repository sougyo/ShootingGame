#ifndef ___CAMERAINFORMATION_H
#define ___CAMERAINFORMATION_H

namespace background {
	namespace camera {
		class CameraInformation;
	}
}

class background::camera::CameraInformation {
public:
	CameraInformation(float deltaX, float deltaY, float deltaZ,
		float deltaRadX, float deltaRadY, float deltaRadZ, long frame);
	inline float getDeltaX(void) const { return deltaX; }
	inline float getDeltaY(void) const { return deltaY; }
	inline float getDeltaZ(void) const { return deltaZ; }
	inline float getDeltaRadX(void) const { return deltaRadX; }
	inline float getDeltaRadY(void) const { return deltaRadY; }
	inline float getDeltaRadZ(void) const { return deltaRadX; }
	inline long getFrame(void) const { return frame; }
private:
	float deltaX;
	float deltaY;
	float deltaZ;
	float deltaRadX;
	float deltaRadY;
	float deltaRadZ;
	long frame;
};

#endif /* ___CAMERAINFORMATION_H */