#ifndef __DIRECTINPUT_H
#define __DIRECTINPUT_H

#include <dinput.h>
// �����J�����́��ǉ��̈ˑ��t�@�C�� �Ɉȉ���ǉ����邱��
// d3d9.lib d3dx9.lib dxerr9.lib dxguid.lib dinput8.lib odbc32.lib odbccp32.lib

#include "keyData.h"
#include "DirectXUtil.h"

namespace gameinpututil {
	static const BUTTONNUM = 5;
	enum Button { Shot, Bomb, Slow, Skip, Pause };

    class DirectInput;
}

// TODO : �Ȃ�Ƃ��Ȃ�� �O������̎Q�� (���̊֐��̓O���[�o���łȂ��ƃG���[ : DirectX������Ă΂��Ǝv����)
BOOL CALLBACK EnumJoyCallback(const DIDEVICEINSTANCE* directInputDeviceInstance, VOID* context);
BOOL CALLBACK EnumAxesCallback(LPCDIDEVICEOBJECTINSTANCE objectInstance, LPVOID ref);

class gameinpututil::DirectInput {
    // TODO : ���t�@�N�^�����O ����ȃN���X
private:
    static DirectInput* directInputSingleton;
    static KeyData* keyData;

	static const int DEADZONE = 400;

    HWND wndApp;

    LPDIRECTINPUT8 directInput;
	LPDIRECTINPUTDEVICE8 directInputDeviceKeyboard;
	LPDIRECTINPUTDEVICE8 directInputDeviceJoypad;

    DIPROPDWORD directInputProp;

    DIDEVICEOBJECTDATA keyboardData;
    DIDEVICEOBJECTDATA joypadData;

    const DWORD* joypadPushKeys;

    bool canUseJoypad;

    bool isUpKey;
    bool isDownKey;
    bool isLeftKey;
    bool isRightKey;

	bool isKeyChecking_;
	bool isAnyKeyPushed;

	DWORD pushedKey;

    DirectInput(void);
    DirectInput(const DirectInput&);
	DirectInput& operator = (const DirectInput&);
    ~DirectInput(void) {}

    void keyboardInit(void);
    void joypadInit(void);

    void checkKeyboardKey(void);
    void checkJoypadKey(void);

    void keyUpProsess(void);
    void keyDownProsess(void);
    void keyLeftProsess(void);
    void keyRightProsess(void);

    void checkKey(int keyNum);

    inline bool isKeyPushed(DWORD data) const { return (data == 0x80); }

public:
	static DirectInput* getInstance(void) { return directInputSingleton; }
	void initInstance(HINSTANCE instApp, HWND wndApp);

    void setKey(const DWORD* joypadPushKeys);
    void checkKey(void);
    void end(void);

	void checkPushKey(void);
	void uncheckPushKey(void);

	inline DWORD getPushedKey(void) const { return pushedKey; }

    inline bool isUp(void) const { return keyData->isUp(); }
    inline bool isDown(void) const { return keyData->isDown(); }
    inline bool isLeft(void) const { return keyData->isLeft(); }
    inline bool isRight(void) const { return keyData->isRight(); }

    inline bool isShot(void) const { return keyData->isShot(); }
    inline bool isBomb(void) const { return keyData->isBomb(); }
    inline bool isSlow(void) const { return keyData->isSlow(); }
    inline bool isSkip(void) const { return keyData->isSkip(); }
    inline bool isPause(void) const { return keyData->isPause(); }

	inline bool isAnyKey(void) const { return isAnyKeyPushed; }
	inline bool isKeyChecking(void) const { return isKeyChecking_; }

	// �f�o�b�O�p
    DWORD getKBNum(void) const { return keyboardData.dwOfs; }
    bool isKBPush(void) const { return (keyboardData.dwData == 0x80); }
    DWORD getJPNum(void) const { return joypadData.dwOfs; }
	DWORD getJPData(void) const { return joypadData.dwData; }

    // TODO : �Ȃ�Ƃ��Ȃ��2 �O������̎Q�� (��̃O���[�o���֐�����Ă΂�邽�ߌ��J)
	BOOL EnumJoyCallback2(const DIDEVICEINSTANCE* directInputDeviceInstance, VOID* context);
    BOOL EnumAxesCallback2(LPCDIDEVICEOBJECTINSTANCE objectInstance, LPVOID ref);
};

#endif // __DIRECTINPUT_H
