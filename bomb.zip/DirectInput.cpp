#define __DIRECTINPUT_CPP

#include "DirectInput.h"

using namespace gameinpututil;
using namespace directxutil;

DirectInput::DirectInput(void) {
	directInput = 0;

	directInputDeviceKeyboard = 0;
	directInputDeviceJoypad = 0;
    canUseJoypad = false;

    isUpKey = false;
    isDownKey = false;
    isLeftKey = false;
    isRightKey = false;

	isKeyChecking_ = false;
	isAnyKeyPushed = false;

	pushedKey = 0;

}

void DirectInput::initInstance(HINSTANCE instApp, HWND wndApp) {
    this->wndApp = wndApp;
    
    HRESULT result;

	result = DirectInput8Create(
		instApp,
		DIRECTINPUT_VERSION,
		IID_IDirectInput8,
        reinterpret_cast<void**>(&directInput),
        0
        );
    checkInit(result);

    keyboardInit();
    if (canUseJoypad) joypadInit();

}

void DirectInput::keyboardInit(void) {
    HRESULT result;
    
    result = directInput->CreateDevice(GUID_SysKeyboard, &directInputDeviceKeyboard, 0);
    checkInit(result);

    result = directInput->EnumDevices(DI8DEVCLASS_GAMECTRL, EnumJoyCallback, 0, DIEDFL_ATTACHEDONLY);
    checkInit(result);
    if (directInputDeviceJoypad == 0) canUseJoypad = false;
    else canUseJoypad = true;

    result = directInputDeviceKeyboard->SetDataFormat(&c_dfDIKeyboard);
    checkInit(result);

    result = directInputDeviceKeyboard->SetCooperativeLevel(wndApp, DISCL_NONEXCLUSIVE | DISCL_BACKGROUND);
    checkInit(result);

    directInputProp.diph.dwSize = sizeof(directInputProp);
    directInputProp.diph.dwHeaderSize = sizeof(directInputProp.diph);
    directInputProp.diph.dwObj = 0;
    directInputProp.diph.dwHow = DIPH_DEVICE;
    directInputProp.dwData = 100;
    result = directInputDeviceKeyboard->SetProperty(DIPROP_BUFFERSIZE, &directInputProp.diph);
    checkInit(result);

    directInputDeviceKeyboard->Acquire();

}

// TODO: �f�b�h�]�[���̒���
void DirectInput::joypadInit(void) {
    HRESULT result;

    result = directInputDeviceJoypad->SetDataFormat(&c_dfDIJoystick2);
    checkInit(result);

    result = directInputDeviceJoypad->SetCooperativeLevel(wndApp, DISCL_NONEXCLUSIVE | DISCL_BACKGROUND);
    checkInit(result);

    directInputProp.diph.dwSize = sizeof(directInputProp);
    directInputProp.diph.dwHeaderSize = sizeof(directInputProp.diph);
    directInputProp.diph.dwObj = 0;
    directInputProp.diph.dwHow = DIPH_DEVICE;
    directInputProp.dwData = DIPROPAXISMODE_ABS;
    result = directInputDeviceJoypad->SetProperty(DIPROP_AXISMODE, &directInputProp.diph);
    checkInit(result);

    result = directInputDeviceJoypad->EnumObjects(EnumAxesCallback, 0, DIDFT_AXIS);
    checkInit(result);

    //directInputProp.diph.dwSize = sizeof(directInputProp);
    //directInputProp.diph.dwHeaderSize = sizeof(directInputProp.diph);
    //directInputProp.diph.dwObj = 0;
    //directInputProp.diph.dwHow = DIPH_DEVICE;
    directInputProp.dwData = 100;
    result = directInputDeviceJoypad->SetProperty(DIPROP_BUFFERSIZE, &directInputProp.diph);
    checkInit(result);

    //directInputProp.diph.dwSize = sizeof(directInputProp);
    //directInputProp.diph.dwHeaderSize = sizeof(directInputProp.diph);
    //directInputProp.diph.dwObj = 0;
    //directInputProp.diph.dwHow = DIPH_DEVICE;
    directInputProp.dwData = 3000;
    result = directInputDeviceJoypad->SetProperty(DIPROP_DEADZONE, &directInputProp.diph);
    checkInit(result);

    directInputDeviceJoypad->Acquire();
}

BOOL DirectInput::EnumJoyCallback2(const DIDEVICEINSTANCE* directInputDeviceInstance, VOID* context) { 
    HRESULT result;

    DIDEVCAPS directInputDeviceJoypadCaps;

    result = directInput->CreateDevice(directInputDeviceInstance->guidInstance, &directInputDeviceJoypad, 0);
    if (isFail(result)) return DIENUM_CONTINUE;

    directInputDeviceJoypadCaps.dwSize = sizeof(DIDEVCAPS);
    result = directInputDeviceJoypad->GetCapabilities(&directInputDeviceJoypadCaps);
    if (isFail(result)) {
        directInputDeviceJoypad->Release();
        directInputDeviceJoypad = 0;
        return DIENUM_CONTINUE;
    }

    return DIENUM_STOP;
}

BOOL CALLBACK EnumJoyCallback(const DIDEVICEINSTANCE* directInputDeviceInstance, VOID* context) {
    return DirectInput::getInstance()->EnumJoyCallback2(directInputDeviceInstance, context);
}

BOOL CALLBACK EnumAxesCallback(LPCDIDEVICEOBJECTINSTANCE objectInstance, LPVOID ref) {
    return DirectInput::getInstance()->EnumAxesCallback2(objectInstance, ref);
}

BOOL DirectInput::EnumAxesCallback2(LPCDIDEVICEOBJECTINSTANCE objectInstance, LPVOID ref) {
    HRESULT result;

    DIPROPRANGE directInputPropRange;

    ZeroMemory(&directInputPropRange,  sizeof(directInputPropRange));
    directInputPropRange.diph.dwSize = sizeof(directInputPropRange);
    directInputPropRange.diph.dwHeaderSize = sizeof(directInputPropRange.diph);
    directInputPropRange.diph.dwObj = objectInstance->dwType;
    directInputPropRange.diph.dwHow = DIPH_BYID;
    directInputPropRange.lMin = -1000;
    directInputPropRange.lMax = +1000;
    result = directInputDeviceJoypad->SetProperty(DIPROP_RANGE, &directInputPropRange.diph);
    if (isFail(result)) return DIENUM_STOP;

    return DIENUM_CONTINUE;
}

void DirectInput::end(void) {
    directInputDeviceKeyboard->Unacquire();
    directInputDeviceKeyboard->Release();
    if (canUseJoypad) {
        directInputDeviceJoypad->Unacquire();
        directInputDeviceJoypad->Release();
    }
    directInput->Release();
}

void DirectInput::setKey(const DWORD* joypadPushKeys) {
    this->joypadPushKeys = joypadPushKeys;
}

void DirectInput::checkKey(void) {
    // TODO : �D�揈������ (���݃L�[�{�[�h�D��)
    checkKeyboardKey();
    if (canUseJoypad) checkJoypadKey();
}

void DirectInput::checkKeyboardKey(void) {
    HRESULT result;
    DWORD keyboardItems;

    while (true) {
        keyboardItems = 1;

        result = directInputDeviceKeyboard->GetDeviceData(
            sizeof(DIDEVICEOBJECTDATA),
            &keyboardData,
            &keyboardItems,
            0
        );
        if (result == DIERR_INPUTLOST) directInputDeviceKeyboard->Acquire();
        else if (isFail(result) || keyboardItems == 0) break;
        else {
            switch (keyboardData.dwOfs) {
                // TODO : �L�[�R���t�B�O�̎���
                case DIK_UP :
                    keyUpProsess();
                    break;

                case DIK_DOWN :
                    keyDownProsess();
                    break;

                case DIK_LEFT :
                    keyLeftProsess();
                    break;

                case DIK_RIGHT :
                    keyRightProsess();
                    break;

                case DIK_Z :
				case DIK_RETURN :
					keyData->setShot(isKeyPushed(keyboardData.dwData)); break;

                case DIK_X :
                    keyData->setBomb(isKeyPushed(keyboardData.dwData)); break;

                case DIK_LSHIFT :
                    keyData->setSlow(isKeyPushed(keyboardData.dwData)); break;

				case DIK_LCONTROL :
				case DIK_RCONTROL :
					keyData->setSkip(isKeyPushed(keyboardData.dwData)); break;

				case DIK_ESCAPE :
				case DIK_P :
					keyData->setPause(isKeyPushed(keyboardData.dwData)); break;

                default:
                    break;
            }
        }
    }
}


void DirectInput::keyUpProsess(void) {
    if (isKeyPushed(keyboardData.dwData)) {
        isUpKey = true;
        keyData->setUp(true);
        if (isDownKey) keyData->setDown(false);
    }
    else {
        isUpKey = false;
        keyData->setUp(false);
        if (isDownKey) keyData->setDown(true);
    }
}

void DirectInput::keyDownProsess(void) {
    if (isKeyPushed(keyboardData.dwData)) {
        isDownKey = true;
        keyData->setDown(true);
        if (isUpKey) keyData->setUp(false);
    }
    else {
        isDownKey = false;
        keyData->setDown(false);
        if (isUpKey) keyData->setUp(true);
    }
}

void DirectInput::keyLeftProsess(void) {
    if (isKeyPushed(keyboardData.dwData)) {
        isLeftKey = true;
        keyData->setLeft(true);
        if (isRightKey) keyData->setRight(false);
    }
    else {
        isLeftKey = false;
        keyData->setLeft(false);
        if (isRightKey) keyData->setRight(true);
    }
}

void DirectInput::keyRightProsess(void) {
    if (isKeyPushed(keyboardData.dwData)) {
        isRightKey = true;
        keyData->setRight(true);
        if (isLeftKey) keyData->setLeft(false);
    }
    else {
        isRightKey = false;
        keyData->setRight(false);
        if (isLeftKey) keyData->setLeft(true);
    }
}

void DirectInput::checkJoypadKey(void) {
    HRESULT result;
    DWORD joypadItems;

    int plot = 0;
    while (true) {
        joypadItems = 1;

        result = directInputDeviceJoypad->Poll();
        if (isFail(result)) {
            result = directInputDeviceJoypad->Acquire();
            while (result == DIERR_INPUTLOST)
                result = directInputDeviceJoypad->Acquire();
        }

        result = directInputDeviceJoypad->GetDeviceData(
            sizeof(DIDEVICEOBJECTDATA),
            &joypadData,
            &joypadItems,
            0
        );
        if (result == DIERR_INPUTLOST)
			directInputDeviceJoypad->Acquire();
        else if (isFail(result) || joypadItems == 0)
			break;
        else {
            switch (joypadData.dwOfs) {
                case DIJOFS_X:
                    plot = static_cast<signed int>(joypadData.dwData);
                    if (plot > DEADZONE) {
                        // �E
                        keyData->setRight(true);
                        keyData->setLeft(false);
                    }
                    else if (plot < -DEADZONE) {
                        // ��
                        keyData->setLeft(true);
                        keyData->setRight(false);
                    }
                    else {
                        // �^��
                        keyData->setRight(false);
                        keyData->setLeft(false);
                    }
                    break;

                case DIJOFS_Y:
                    plot = static_cast<signed int>(joypadData.dwData);
                    if (plot > DEADZONE) {
                        // ��
                        keyData->setDown(true);
                        keyData->setUp(false);
                    }
                    else if (plot < -DEADZONE) {
                        // ��
                        keyData->setUp(true);
                        keyData->setDown(false);
                    }
                    else {
                        // �^��
                        keyData->setUp(false);
                        keyData->setDown(false);
                    }
                    break;

                default:
                    DWORD key = joypadData.dwOfs;

					if (isKeyChecking_ && isKeyPushed(joypadData.dwData) && key < 60) {
						isAnyKeyPushed = true;
						pushedKey = key;
					}
					else {
						for(int i = 0; i < BUTTONNUM; i++)
							if (key == joypadPushKeys[i]) checkKey(i);
					}
                    break;
            }
        }
    }
}

void DirectInput::checkKey(int keyNum) {
    switch (keyNum) {
        case Shot:
            keyData->setShot(isKeyPushed(joypadData.dwData)); break;

        case Bomb:
            keyData->setBomb(isKeyPushed(joypadData.dwData)); break;

        case Slow:
            keyData->setSlow(isKeyPushed(joypadData.dwData)); break;

        case Skip:
            keyData->setSkip(isKeyPushed(joypadData.dwData)); break;

        case Pause:
            keyData->setPause(isKeyPushed(joypadData.dwData)); break;

        default:
            break;
    }
}

void DirectInput::checkPushKey(void) {
	isKeyChecking_ = true;
	isAnyKeyPushed = false;
	pushedKey = 0;
}

void DirectInput::uncheckPushKey(void) {
	isKeyChecking_ = false;
	isAnyKeyPushed = false;
	pushedKey = 0;
}

DirectInput* DirectInput::directInputSingleton = new DirectInput();

KeyData* DirectInput::keyData = new KeyData();
