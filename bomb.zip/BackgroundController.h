#ifndef ___BACKGROUNDCONTROLLER_H
#define ___BACKGROUNDCONTROLLER_H

#include <string>
#include <vector>
#include "BackgroundInterpreter.h"
#include "Camera.h"
#include "ImageX.h"
#include "ImageFactory.h"
#include "Effect3D.h"

namespace background {
	class BackgroundController;
}

class background::BackgroundController {
public:
	static BackgroundController* getInstance(void) {
		return singleton;
	}

	void load(std::string fileName);
	void load(int stageNo);
	void move(void);
	void draw(void);
	void nextState(void);
	inline claen(void) {
		eff->reset();
		interpreter->finalize();
	}
private:
	static BackgroundController* singleton;

	double crntZ;

	BackgroundController(void);
	BackgroundController(const BackgroundController&);
	BackgroundController& operator=(const BackgroundController&);

	BackgroundInterpreter* interpreter;
	double distanceZ;

	std::vector<graphics::ImageX*> xFiles;
	graphics::Camera* cam;
	::effect::Effect3D* eff;
};

#endif	/* ___BACKGROUNDCONTROLLER_H */