#ifndef __KEYCONFIG_H
#define __KEYCONFIG_H

#include "DirectInput.h"

namespace gameinpututil {
	class KeyConfig;
}

class gameinpututil::KeyConfig {
private:
    static KeyConfig* keyConfigSingleton;

	DirectInput* directInput;

	DWORD joypadPushKeys[BUTTONNUM];

    KeyConfig(void);
    KeyConfig(const KeyConfig&);
	KeyConfig& operator = (const KeyConfig&);
    ~KeyConfig(void);

public:
	static KeyConfig* getInstance(void) { return keyConfigSingleton;}

	void initInstance(DirectInput* directInput);

	void setJoypadPushedKey(Button buttonNum);
	inline void setKey(void) { directInput->setKey(joypadPushKeys); }

    void resetKey(void);

	inline DWORD getJoypadPushKeyNum(Button buttonNum) const { return joypadPushKeys[buttonNum]; }

	void end(void);

	static Button getButton(int num);
};

#endif // __KEYCONFIG_H