#include "ImageSprite.h"

#pragma warning(disable : 4244)

using namespace graphics;

ImageSprite::ImageSprite(LPDIRECT3DDEVICE9& device, const std::string& fileName, LPD3DXSPRITE& sprite) {
	//�摜�t�@�C������e�N�X�`���쐬
	D3DXCreateTextureFromFile(device, fileName.c_str(), &texture);

	this->sprite = sprite;

	height = 10;
	width = 10;
	centerX = width/2.0f;
	centerY = height/2.0f;
}

ImageSprite::~ImageSprite(void)
{
}

void ImageSprite::drawImage(double angle, int movX, int movY) {

	rad = angle*(3.14159265/180);

	this->setTransformZ(rad,movX,movY);

	/*sprite->Draw(texture, 0,
                 &D3DXVECTOR3(centerX, centerY, 0),
                 0, 0xffffffff);*/
}

void ImageSprite::setTransformZ(double rad, int movX, int movY) {
	D3DXMatrixScaling(&matrixScale, 2.0f, 2.0f, 1.0f);
	D3DXMatrixRotationZ(&matrixRad, rad);
	D3DXMatrixTranslation(&matrixMov, 100.0f, 100.0f, 0.0f);
	D3DXMatrixIdentity(&matrixWorld);
	D3DXMatrixMultiply(&matrixMult, &matrixScale, &matrixRad);
	D3DXMatrixMultiply(&matrixWorld, &matrixMult, &matrixMov);

	//sprite->SetTransform(&matrixWorld);
}