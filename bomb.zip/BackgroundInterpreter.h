#ifndef ___BACKGROUNDINTERPRETER_H
#define ___BACKGROUNDINTERPRETER_H

#include <vector>
#include <string>

#include "CommandGroups.h"
#include "EffectGroup.h"
#include "XFileGroup.h"

namespace background {
	class BackgroundInterpreter;
}

class background::BackgroundInterpreter {
public:
	static BackgroundInterpreter* getInstance(void) { return singleton; }
	~BackgroundInterpreter(void) { finalize(); }
	void finalize(void);

	inline void updateCmd(void) { frame4Cmd++; }
	inline void updateEff(void) { frame4Eff++; }
	inline void update(void) {
		updateCmd();
		updateEff();
	}

	inline void nextState(void) { state++; }

	background::camera::CameraInformation* getCamInfo(void) const;
	inline ::effect::EffectInformation* getEffInfo(void) const {
		return effects[state]->getEffect(frame4Eff);
	}
	inline background::xfile::XFileGroup* getXFiles(void) const {
		return xfiles[state];
	}
	void interpret(std::string fileName);
private:
	static BackgroundInterpreter* singleton;
	std::vector<char> CHARA;

	BackgroundInterpreter(void) : index(0), commands(0), effects(0), xfiles(0) {
		for (int i = 'a'; i <= 'z'; ++i) CHARA.push_back(static_cast<char>(i));
		for (int i = 'A'; i <= 'Z'; ++i) CHARA.push_back(static_cast<char>(i));
		CHARA.push_back('_');
		element = "";
		isStatement = false;
		wasWS = false;
		wasCamera = false;
		frame4Cmd = frame4Eff = 0LU;
	}
	BackgroundInterpreter(const BackgroundInterpreter&);
	BackgroundInterpreter& operator=(const BackgroundInterpreter&);

	int state;
	int index;
	int MAX_FRAME;
	unsigned long frame4Cmd;
	unsigned long frame4Eff;
	std::vector<background::command::CommandGroups*> commands;
	std::vector<background::effect::EffectGroup*> effects;
	std::vector<background::xfile::XFileGroup*> xfiles;

	bool isStatement;
	bool wasWS;
	bool wasCamera;
	std::string element;
	int frame;
	std::vector<const std::string> elements;

	void interpret(char ch);
	void start(char ch);
	void label(char ch);
	void xFile(char ch);
	void camera(char ch);
	void effect(char ch);
	void until(char ch);
	void wait(char ch);
	void preXFile(char ch);
	void preCamera(char ch);
	void preEffect(char ch);
	void preUntil(char ch);

	void init(void);

	inline bool isWS(char ch) {
		return ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n';
	}
	inline bool isChara(char ch) {
		for (unsigned int i = 0; i < CHARA.size(); ++i)
			if (ch == CHARA[i]) return true;
		return false;
	}
};

#endif	/* ___BACKGROUNDINTERPRETER_H */