#include "BackgroundInterpreter.h"

using namespace background;

#include <iomanip>
#include <fstream>
#include <cassert>

BackgroundInterpreter* BackgroundInterpreter::singleton = new BackgroundInterpreter();

background::camera::CameraInformation* BackgroundInterpreter::getCamInfo(void) const {
	unsigned long frame = frame4Cmd % MAX_FRAME;
	int cmdIndex = 0;
	int frameSum = 0;
	unsigned int untilCrnt = 0;
	for (unsigned int i = 0; i < commands.size(); ++i) {
		untilCrnt += commands[i]->getFrame();
		if (frame < untilCrnt) {
			cmdIndex = i;
			frame -= frameSum;
			break;
		}
		frameSum += commands[i]->getFrame();
	}
	return this->commands[cmdIndex]->getCommandGroup()->getCommand(frame);
}

void BackgroundInterpreter::finalize(void) {
	if (!commands.empty()) {
		for (unsigned int i = 0; i < commands.size(); ++i) {
			//commands[i]->finalize();
			delete commands.at(i);
		}
		commands.clear();
	}
	if (!effects.empty()) {
		for (unsigned int i = 0; i < effects.size(); ++i) {
			//effects[i]->finalize();
			delete effects.at(i);
		}
		effects.clear();
	}
	if (!xfiles.empty()) {
		for (unsigned int i = 0; i < xfiles.size(); ++i) {
			//xfiles[i]->finalize();
			delete xfiles.at(i);
		}
		xfiles.clear();
	}
}

namespace {
	enum Kind { START, LABEL, XFILE, CAMERA, EFFECT, UNTIL, preXFILE, preCAMERA, preEFFECT, preUNTIL, WAIT, };
	const char FILE_[] = { 'f', 'i', 'l', 'e' };
	const char AMERA[] = { 'a', 'm', 'e', 'r', 'a' };
	const char FFECT[] = { 'f', 'f', 'e', 'c', 't' };
	const char NTIL[] = { 'n', 't', 'i', 'l' };
}

void BackgroundInterpreter::interpret(std::string fileName) {
	init();
	state = START;
	std::ifstream in(fileName.c_str());
	bool isComment = false;
	char ch;
	in >> ch;
	while (!in.eof()) {
		interpret(ch);
		if (!isComment && ch != ';')
			in >> std::noskipws >> ch;
		else if (!isComment) {
			isComment = true;
		} else if (ch == '\n') {
			isComment = false;
		}
	}
	// interpret(ch);	// TODO : �K�v���ǂ����`�F�b�N���邱��
	MAX_FRAME = 0;
	for (unsigned int i = 0; i < commands.size(); ++i)
		MAX_FRAME += commands[i]->getFrame();
}

void BackgroundInterpreter::interpret(char ch) {
	switch (this->state) {
		case START:		start(ch);	break;
		case LABEL:		label(ch);	break;
		case XFILE:		xFile(ch);	break;
		case CAMERA:	camera(ch);	break;
		case EFFECT:	effect(ch);	break;
		case UNTIL:		until(ch);	break;
		case WAIT:		wait(ch);	break;
		case preXFILE:	preXFile(ch);	break;
		case preCAMERA:	preCamera(ch);	break;
		case preEFFECT:	preEffect(ch);	break;
		case preUNTIL:	preUntil(ch);	break;
	}
}

void BackgroundInterpreter::start(char ch) {
	if (isWS(ch)) return;
	if (isChara(ch)) {
		this->state = LABEL;
		return;
	}
	assert(false);
}

void BackgroundInterpreter::label(char ch) {
	if (isWS(ch) || ch == '{') {
		this->state = WAIT;
		return;
	} else if (isChara(ch)) return;
	assert(false);
}

void BackgroundInterpreter::wait(char ch) {
	if (isWS(ch) || ch == '{') return;
	if (ch == 'x') { /*isEnd = false;*/ this->state = preXFILE; return; }
	if (ch == 'c') { /*isEnd = false;*/ this->state = preCAMERA; return; }
	if (ch == 'e') { /*isEnd = false;*/ this->state = preEFFECT; return; }
	if (ch == 'u') { /*isEnd = false;*/ this->state = preUNTIL; return; }		// TODO : �����֐��ŏ������Ă������`�F�b�N���邱��
	if (ch == '}') {
		if (wasCamera) {
			wasCamera = false;
			this->state = WAIT;
			return;
		} else {
			this->state = START;
			return;
		}
	}
	assert(false);
}

void BackgroundInterpreter::preXFile(char ch) {
	if (ch == FILE_[index]) {
		if (index == sizeof(FILE_) / sizeof(FILE_[0]) -1) {
			index = 0;
			this->state = XFILE;
		} else ++index;
		return;
	}
	assert(false);
}

void BackgroundInterpreter::preCamera(char ch) {
	if (ch == AMERA[index]) {
		if (index == sizeof(AMERA) / sizeof(AMERA[0]) -1) {
			index = 0;
			this->state = WAIT;
		} else ++index;
		return;
	}
	assert(false);
}

void BackgroundInterpreter::preEffect(char ch) {
	if (ch == FFECT[index]) {
		if (index == sizeof(FFECT) / sizeof(FFECT[0]) -1) {
			index = 0;
			this->state = EFFECT;
		} else ++index;
		return;
	}
	assert(false);
}

void BackgroundInterpreter::preUntil(char ch) {
	if (ch == NTIL[index]) {
		if (index == sizeof(NTIL) / sizeof(NTIL[0]) -1) {
			index = 0;
			this->state = UNTIL;
		} else ++index;
		return;
	}
	assert(false);
}

void BackgroundInterpreter::until(char ch) {
	if (isWS(ch) || ch == '{') {
		frame = atoi(element.c_str());
		element.clear();
		this->state = CAMERA;
		return;
	} else if (isdigit(ch)) {
		element += ch;
		return;
	} else if (ch == '}') {
		this->state = WAIT;
		return;
	}
	assert(false);
}

void BackgroundInterpreter::xFile(char ch) {
	if ((isWS(ch) || ch == '{') && !isStatement) return;
	if (ch == '\n') {
		isStatement = false;
		wasWS = false;
		elements.push_back(element);
		element.clear();
		return;
	} else if (!wasWS && isWS(ch)) {
		wasWS = true;
		element += ' ';
		return;
	} else if (wasWS && isWS(ch)) {
		return;
	} else if (isChara(ch) || isdigit(ch) || ch == ',' || ch == '-' || ch == '.') {
		wasWS = false;
		isStatement = true;
		element += ch;
		return;
	} else if (ch == '}') {
		isStatement = false;
		wasWS = false;
		element.clear();
		xfiles.push_back(new background::xfile::XFileGroup(elements));
		elements.clear();
		this->state = WAIT;
		return;
	}
	assert(false);
}

void BackgroundInterpreter::camera(char ch) {
	if ((isWS(ch) || ch == '{') && !isStatement) return;
	if (ch == '\n') {
		isStatement = false;
		wasWS = false;
		elements.push_back(element);
		element.clear();
		return;
	} else if (!wasWS && isWS(ch)) {
		wasWS = true;
		element += ' ';
		return;
	} else if (wasWS && isWS(ch)) {
		return;
	} else if (isChara(ch) || isdigit(ch) || ch == ',' || ch == '-' || ch == '.') {
		wasWS = false;
		isStatement = true;
		element += ch;
		return;
	} else if (ch == '}') {
		wasCamera = true;
		isStatement = false;
		wasWS = false;
		element.clear();
		background::command::CommandGroup* c = new background::command::CommandGroup(elements);
		commands.push_back(new background::command::CommandGroups(
			c, frame));
		elements.clear();
		this->state = WAIT;
		frame = 0;
		return;
	}
	assert(false);
}

void BackgroundInterpreter::effect(char ch) {
	if ((isWS(ch) || ch == '{') && !isStatement) return;
	if (ch == '\n') {
		isStatement = false;
		wasWS = false;
		elements.push_back(element);
		element.clear();
		return;
	} else if (!wasWS && isWS(ch)) {
		wasWS = true;
		element += ' ';
		return;
	} else if (wasWS && isWS(ch)) {
		return;
	} else if (isChara(ch) || isdigit(ch) || ch == ',' || ch == '-' || ch == '.') {
		wasWS = false;
		isStatement = true;
		element += ch;
		return;
	} else if (ch == '}') {
		isStatement = false;
		wasWS = false;
		element.clear();
		effects.push_back(new background::effect::EffectGroup(elements));
		elements.clear();
		this->state = WAIT;
		return;
	}
	assert(false);
}

void BackgroundInterpreter::init(void) {
//	finalize();
	state = START;
	index = 0;
	frame4Cmd = 0;
	frame4Eff = 0;

	isStatement = false;
	wasWS = false;
	wasCamera = false;
	element.clear();
	elements.clear();
}