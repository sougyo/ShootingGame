#ifndef ___COMMANDGROUP_H
#define ___COMMANDGROUP_H

#include <vector>
#include <string>

#include "CameraInformation.h"

namespace background {
	namespace command {
		class CommandGroup;
	}
}

class background::command::CommandGroup {
public:
	CommandGroup(const std::vector<const std::string>& cmdList);
	~CommandGroup(void) { finalize(); }
	camera::CameraInformation* getCommand(unsigned long crntFrame) const;
	void finalize(void);
private:
	std::vector<const std::string> OP;

	std::vector<camera::CameraInformation*> cameraInfo;
	int frameSum;
	double crntX;
	double crntY;
	double crntZ;

	void analyze(const std::string& command);
public:
	void push(camera::CameraInformation* info);
	inline void setCurrent(double x, double y, double z) {
		this->crntX += x;
		this->crntY += y;
		this->crntZ += z;
	}
	inline double getCrntX(void) { return crntX; }
	inline double getCrntY(void) { return crntY; }
	inline double getCrntZ(void) { return crntZ; }
};

#endif	/* ___COMMANDGROUP_H */