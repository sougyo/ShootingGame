#include "CommandGroup.h"

#include <cstdlib>
#include <cassert>
#include "StringUtil.h"
#include "gameMath.h"

using namespace background::command;

namespace {	
	void analyzeNop(CommandGroup* self, const std::string noOp);
	void analyzeMove(CommandGroup* self, const std::string noOp);
	void analyzeRote(CommandGroup* self, const std::string noOp);
	void analyzeStop(CommandGroup* self, const std::string noOp);
	void analyzeInfo(CommandGroup* self, const std::string noOp);
	void analyzeMovX(CommandGroup* self, const std::string noOp);
	void analyzeMovY(CommandGroup* self, const std::string noOp);
	void analyzeMovZ(CommandGroup* self, const std::string noOp);
	void analyzeRotX(CommandGroup* self, const std::string noOp);
	void analyzeRotY(CommandGroup* self, const std::string noOp);
	void analyzeRotZ(CommandGroup* self, const std::string noOp);

	void (*analyzer[])(CommandGroup* self, const std::string) = {
			analyzeNop,
			analyzeMove,
			analyzeRote,
			analyzeStop,
			analyzeInfo,
			analyzeMovX,
			analyzeMovY,
			analyzeMovZ,
			analyzeRotX,
			analyzeRotY,
			analyzeRotZ
	};
}

CommandGroup::CommandGroup(const std::vector<const std::string>& cmdList) {
	crntX = crntY = crntZ = 0.0;
	OP.push_back("nop");
	OP.push_back("mov");
	OP.push_back("rot");
	OP.push_back("stop");
	OP.push_back("info");
	OP.push_back("movX");
	OP.push_back("movY");
	OP.push_back("movZ");
	OP.push_back("rotX");
	OP.push_back("rotY");
	OP.push_back("rotZ");
	for (unsigned int i = 0; i < cmdList.size(); i++){
		analyze(cmdList[i]);
	}

	frameSum = 0;
	for (unsigned int i = 0; i < cameraInfo.size(); i++)
		frameSum += cameraInfo[i]->getFrame();
}

background::camera::CameraInformation* CommandGroup::getCommand(unsigned long crntFrame) const {
	int index = 0;
	int frame = crntFrame % frameSum;
	for (unsigned int i = 0; i < cameraInfo.size(); i++, index++) {
		frame -= cameraInfo[i]->getFrame();
		if (frame < 0) break;
	}
	return this->cameraInfo[index];
}

void CommandGroup::finalize(void) {
	if (cameraInfo.empty()) return;
	for (unsigned int i = 0; i < cameraInfo.size(); ++i) {
		delete cameraInfo.at(i);
	}
	cameraInfo.clear();
}

void CommandGroup::analyze(const std::string& command) {
	using lang::util::StringUtil;
	//===========================================
	std::string op   = StringUtil::substring(command, 0, StringUtil::indexOf(command, ' '));
	std::string noOp = StringUtil::substring(command, op.length() + 1, command.length());

	for (unsigned int i = 0; i < OP.size(); i++) {
		if (op == OP[i]) {
			analyzer[i](this, noOp);
			break;
		}
	}
}

void CommandGroup::push(background::camera::CameraInformation* info) {
	cameraInfo.push_back(info);
}

namespace {

struct SubstrInfo {
	size_t start;
	size_t end;
	SubstrInfo(size_t start, size_t end) {
		this->start = start;
		this->end = end;
	}
};

SubstrInfo getArg(const std::string args, int count) {
	size_t start = 0;
	size_t end = args.find(",", 0);
	for (int i = 0; i < count; i++) {
		start = end + 1;
		end = args.find(",", start);
	}
	return SubstrInfo(start, end);
}

long toLong(const std::string str) {
	return atol(str.c_str());
}

float toFloat(const std::string str) {
	return static_cast<float>(atof(str.c_str()));
}

void push(CommandGroup* self, float x, float y, float z, float degX, float degY, float degZ, long frame) {
	using gamemath::toRadian;
	self->setCurrent(x * frame, y * frame, z * frame);
	self->push(
		new background::camera::CameraInformation(
			x,
			y,
			z,
			static_cast<float>(toRadian(degX)),
			static_cast<float>(toRadian(degY)),
			static_cast<float>(toRadian(degZ)),
			frame)
		);
}

void analyzeNop(CommandGroup* self, const std::string noOp) {
	long frame = toLong(noOp);
	push(self,0,0,0,0,0,0,frame);
}

// TODO : �����܂�
void analyzeMove(CommandGroup* self, const std::string noOp) {
	float delta[3];
	long frame;
	for (int i = 0; i < 4; i++) {
		SubstrInfo info = getArg(noOp, i);
		std::string arg = lang::util::StringUtil::substring(noOp, info.start, info.end);
		if (i == 3) frame = toLong(arg);
		else delta[i] = toFloat(arg);
	}
	push(self,delta[0],delta[1],delta[2],0,0,0,frame);
}

void analyzeRote(CommandGroup* self, const std::string noOp) {
	float delta[3];
	long frame;
	for (int i = 0; i < 4; i++) {
		SubstrInfo info = getArg(noOp, i);
		std::string arg = lang::util::StringUtil::substring(noOp, info.start, info.end);
		if (i == 3) frame = toLong(arg);
		else delta[i] = toFloat(arg);
	}
	push(self,0,0,0,delta[0],delta[1],delta[2],frame);
}

void analyzeStop(CommandGroup* self, const std::string noOp) {
	long frame = toLong(noOp);
	float x = static_cast<float>(self->getCrntX() / -frame);
	float y = static_cast<float>(self->getCrntY() / -frame);
	float z = static_cast<float>(self->getCrntZ() / -frame);
	push(self,x,y,z,0,0,0,frame);
	//for (int i = 0; i < frame; i++) {
	//	push(self,x,y,z,0,0,0,1);
	//}
}

void analyzeInfo(CommandGroup* self, const std::string noOp) {
	float delta[6];
	long frame;
	for (int i = 0; i < 7; i++) {
		SubstrInfo info = getArg(noOp, i);
		std::string arg = lang::util::StringUtil::substring(noOp, info.start, info.end);
		if (i == 6) frame = toLong(arg);
		else delta[i] = toFloat(arg);
	}
	push(self,delta[0],delta[1],delta[2],delta[3],delta[4],delta[5],frame);
}

void analyzeMovX(CommandGroup* self, const std::string noOp) {
	float x;
	long frame;
	for (int i = 0; i < 2; i++) {
		SubstrInfo info = getArg(noOp, i);
		std::string arg = lang::util::StringUtil::substring(noOp, info.start, info.end);
		if (i == 2) frame = toLong(arg);
		else x = toFloat(arg);
	}
	push(self,x,0,0,0,0,0,frame);
}

void analyzeMovY(CommandGroup* self, const std::string noOp) {
	float y;
	long frame;
	for (int i = 0; i < 2; i++) {
		SubstrInfo info = getArg(noOp, i);
		std::string arg = lang::util::StringUtil::substring(noOp, info.start, info.end);
		if (i == 2) frame = toLong(arg);
		else y = toFloat(arg);
	}
	push(self,0,y,0,0,0,0,frame);
}

void analyzeMovZ(CommandGroup* self, const std::string noOp) {
	float z;
	long frame;
	for (int i = 0; i < 2; i++) {
		SubstrInfo info = getArg(noOp, i);
		std::string arg = lang::util::StringUtil::substring(noOp, info.start, info.end);
		if (i == 2) frame = toLong(arg);
		else z = toFloat(arg);
	}
	push(self,0,0,z,0,0,0,frame);
}

void analyzeRotX(CommandGroup* self, const std::string noOp) {
	float x;
	long frame;
	for (int i = 0; i < 2; i++) {
		SubstrInfo info = getArg(noOp, i);
		std::string arg = lang::util::StringUtil::substring(noOp, info.start, info.end);
		if (i == 2) frame = toLong(arg);
		else x = toFloat(arg);
	}
	push(self,0,0,0,x,0,0,frame);
}

void analyzeRotY(CommandGroup* self, const std::string noOp) {
	float y;
	long frame;
	for (int i = 0; i < 2; i++) {
		SubstrInfo info = getArg(noOp, i);
		std::string arg = lang::util::StringUtil::substring(noOp, info.start, info.end);
		if (i == 2) frame = toLong(arg);
		else y = toFloat(arg);
	}
	push(self,0,0,0,0,y,0,frame);
}

void analyzeRotZ(CommandGroup* self, const std::string noOp) {
	float z;
	long frame;
	for (int i = 0; i < 2; i++) {
		SubstrInfo info = getArg(noOp, i);
		std::string arg = lang::util::StringUtil::substring(noOp, info.start, info.end);
		if (i == 2) frame = toLong(arg);
		else z = toFloat(arg);
	}
	push(self,0,0,0,0,0,z,frame);
}

} // �������O��Ԃ̏I��