#include "FontFactory.h"

using namespace font;

FontFactory::FontFactory(void) {
}
FontFactory::~FontFactory(void) {
}

void FontFactory::initialize(HDC hdc) {
	this->hdc = hdc;
}

Font* FontFactory::createFont(int x1, int y1, int x2, int y2, int height, int width, bool isLeft) {
	return new Font(this->device,x1,y1,x2,2,height,width,true);
}
Font* FontFactory::createFont(void) {
	return new Font();
}

void FontFactory::initialize(LPDIRECT3DDEVICE9& device) {
	this->device = device;
}

FontFactory* FontFactory::singleton = new FontFactory();