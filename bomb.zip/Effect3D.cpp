#include "Effect3D.h"
#include "gameMath.h"

#include <ctime>
#include <cstdlib>
#include <math.h>

using namespace effect;
using namespace graphics;

Effect3D::Effect3D(void) {
	srand(static_cast<UINT>(time(NULL)));
}
Effect3D::~Effect3D(void) {
}

void Effect3D::initialize(LPDIRECT3DDEVICE9& device) {
	this->device = device;

	camera = graphics::Camera::getInstance();

	ImageFactory* imageFactory = graphics::ImageFactory::getInstance();
	rain.image = imageFactory->createImage("./Effect3D/image/rain(1,512).bmp",0.1f);
	fog2D.image = imageFactory->createImage("./Effect3D/image/fog(512,512).jpg",0.3f);
	water3D.image = imageFactory->createImage("./Effect3D/image/water(580,580).jpg",1.0f);
	lava.image = imageFactory->createImage("./Effect3D/image/lava(580,580).jpg",1.0f);
	sky.image = imageFactory->createImage("./Effect3D/image/sky(640,480).jpg",1.0f);
	tornado.image = imageFactory->createImage("./Effect3D/image/tornado(512,512).jpg",1.0f);

	stg1.imageX = imageFactory->createImageX("./Effect3D/XFile/STG1/stage1.x");
	stg2.imageX = imageFactory->createImageX("./Effect3D/XFile/STG2/stage2.x");
	stg3.imageX = imageFactory->createImageX("./Effect3D/XFile/STG3/stage3.x");
	stg4.imageX = imageFactory->createImageX("./Effect3D/XFile/STG4/stage4.x");
	stg5.imageX = imageFactory->createImageX("./Effect3D/XFile/STG5/stage5.x");
	stg6.imageX = imageFactory->createImageX("./Effect3D/XFile/STG6/stage6.x");

	stg1Boss.imageX = imageFactory->createImageX("./Effect3D/XFile/STG1BOSS/stage1_boss.x");
	stg2Boss.imageX = imageFactory->createImageX("./Effect3D/XFile/STG2BOSS/stage2_boss.x");
	stg3Boss.imageX = imageFactory->createImageX("./Effect3D/XFile/STG3BOSS/stage3_boss.x");
	stg4Boss.imageX = imageFactory->createImageX("./Effect3D/XFile/STG4BOSS/stage4_boss.x");
	stg5Boss.imageX = imageFactory->createImageX("./Effect3D/XFile/STG5BOSS/stage5_boss.x");
	stg6Boss.imageX = imageFactory->createImageX("./Effect3D/XFile/STG6BOSS/stage6_boss.x");
	stg7Boss.imageX = imageFactory->createImageX("./Effect3D/XFile/STG2BOSS/stage2_boss.x");
}

void Effect3D::reset(void) {
	stg1.active = false;
	stg2.active = false;
	stg3.active = false;
	stg4.active = false;
	stg5.active = false;
	stg6.active = false;
	stg1Boss.active = false;
	stg2Boss.active = false;
	stg3Boss.active = false;
	stg4Boss.active = false;
	stg5Boss.active = false;
	stg6Boss.active = false;
	stg7Boss.active = false;

	stg1.frame = 0;
	stg2.frame = 0;
	stg3.frame = 0;
	stg4.frame = 0;
	stg5.frame = 0;
	stg6.frame = 0;
	stg1Boss.frame = 0;
	stg2Boss.frame = 0;
	stg3Boss.frame = 0;
	stg4Boss.frame = 0;
	stg5Boss.frame = 0;
	stg6Boss.frame = 0;
	stg7Boss.frame = 0;

	camdata.angleX = 0;
	camdata.angleY = 0;
	camdata.angleZ = 0;
	camdata.movX = 0;
	camdata.movY = 0;
	camdata.movZ = 0;
	camdata.vX = 0;
	camdata.vY = 0;
	camdata.vZ = 0;
	camdata.vangleX = 0;
	camdata.vangleY = 0;
	camdata.vangleZ = 0;
	//this->resetCameraParam();
}

void Effect3D::setEffectInfo(effect::EffectInformation& effectInfo, EffectData& data) {
	data.active = true;
	data.strength = effectInfo.getStrength();
	data.frame = effectInfo.getFrame();
}

void Effect3D::setEffectInfoCamera(effect::EffectInformation& effectInfo, EffectData& data,
							float angleX, float angleY, float angleZ, float movX, float movY, float movZ, float vX, float vY, float vZ) {
	if (data.frame <= 0) {
		this->setEffectInfo(effectInfo,data);
		this->setCameraParam(angleX,angleY,angleZ,movX,movY,movZ,vX,vY,vZ,0,0,0,data);
	}
}

void Effect3D::setCameraParam(float angleX, float angleY, float angleZ, float movX, float movY, float movZ,
							  float vX, float vY, float vZ, EffectData& data) {
	this->setCameraParam(angleX,angleY,angleZ,movX,movY,movZ,vX,vY,vZ,0,0,0,data);
}
void Effect3D::setCameraParam(float angleX, float angleY, float angleZ, float movX, float movY, float movZ,
							  float vX, float vY, float vZ, float vangleX, float vangleY, float vangleZ, EffectData& data) {
	camdata.angleX = angleX;
	camdata.angleY = angleY;
	camdata.angleZ = angleZ;
	camdata.movX = movX;
	camdata.movY = movY;
	camdata.movZ = movZ;
	camdata.vX = vX;
	camdata.vY = vY;
	camdata.vZ = vZ;
	camdata.vangleX = vangleX;
	camdata.vangleY = vangleY;
	camdata.vangleZ = vangleZ;
	this->resetCameraParam();
}

void Effect3D::resetCameraParam(void) {
	camera->setRotateCamera(camdata.angleX,camdata.angleY,camdata.angleZ);
	camera->setPosition(camdata.movX,camdata.movY,camdata.movZ);
	camera->setVelocity(camdata.vX,camdata.vY,camdata.vZ);
	camera->setVelocityRotateCamera(camdata.vangleX,camdata.vangleY,camdata.vangleZ);
}

void Effect3D::fire(effect::EffectInformation& effectInfo) {
	switch(effectInfo.getType()) {
		case effect::EffectInformation::RAIN:
			this->setEffectInfo(effectInfo,rain);
			break;
		case effect::EffectInformation::FOG_2D:
			this->setEffectInfo(effectInfo,fog2D);
			break;
		case effect::EffectInformation::WATER_3D:
			this->setEffectInfo(effectInfo,water3D);
			break;
		case effect::EffectInformation::LAVA:
			this->setEffectInfo(effectInfo,lava);
			break;
		case effect::EffectInformation::SKY:
			this->setEffectInfo(effectInfo,sky);
			break;
		case effect::EffectInformation ::TORNADO:
			this->setEffectInfo(effectInfo,tornado);
			break;

		// �X�e�[�W�P
		case effect::EffectInformation::STG1:
			this->setEffectInfoCamera(effectInfo,stg1,30,0,0,0,-11,0,0,0,-0.5);
			break;
		// �X�e�[�W�Q
		case effect::EffectInformation::STG2:
			this->setEffectInfoCamera(effectInfo,stg2,30,0,0,0,-10,0,0,0,-0.5);
			break;
		// �X�e�[�W�R
		case effect::EffectInformation::STG3:
			this->setEffectInfoCamera(effectInfo,stg3,30,0,0,0,-10,0,0,0,-0.25);
			break;
		// �X�e�[�W�S
		case effect::EffectInformation::STG4:
			this->setEffectInfoCamera(effectInfo,stg4,30,0,0,0,-10,0,0,0,-0.25);
			break;
		// �X�e�[�W�T
		case effect::EffectInformation::STG5:
			this->setEffectInfoCamera(effectInfo,stg5,30,0,0,0,-10,0,0,0,-0.25);
			break;
		// �X�e�[�W�U
		case effect::EffectInformation::STG6:
			this->setEffectInfoCamera(effectInfo,stg6,35,0,0,0,-6,0,0,0,-0.25);
			break;

		// �{�X�X�e�[�W�P
		case effect::EffectInformation::STG1_BOSS:
			this->setEffectInfoCamera(effectInfo,stg1Boss,60,0,0,0,-13,10,0,0,0);
			break;
		// �{�X�X�e�[�W�Q
		case effect::EffectInformation::STG2_BOSS:
			this->setEffectInfoCamera(effectInfo,stg2Boss,20,0,0,0,-9,19,0,0,0);
			break;
		// �{�X�X�e�[�W�R
		case effect::EffectInformation::STG3_BOSS:
			this->setEffectInfoCamera(effectInfo,stg3Boss,10,0,0,0,-6,19,0,0,0);
			break;
		// �{�X�X�e�[�W�S
		case effect::EffectInformation::STG4_BOSS:
			this->setEffectInfoCamera(effectInfo,stg4Boss,25,0,0,0,-6,10,0,0,0);
			break;
		// �{�X�X�e�[�W�T
		case effect::EffectInformation::STG5_BOSS:
			this->setEffectInfoCamera(effectInfo,stg5Boss,45,0,0,0,-20,20,0,0,0);
			break;
		// �{�X�X�e�[�W�U
		case effect::EffectInformation::STG6_BOSS:
			this->setEffectInfoCamera(effectInfo,stg6Boss,15,0,0,0,-10,20,0,0,0);
			break;
		// �{�X�X�e�[�W�V
		case effect::EffectInformation::STG7_BOSS:
			this->setEffectInfoCamera(effectInfo,stg7Boss,0,0,0,0,0,0,0,0,0);
			break;

		default:
			break;
	}
}


void Effect3D::setParamater(effect::EffectInformation& effectInfo, int x, int y, int z) {
	// �����Ȃ�
}

void Effect3D::moveIn(EffectData& data) {
	if (data.active == true) {
		data.frame--;
		if (data.frame < 0)
			data.active = false;
	}
}

void Effect3D::move(void) {
	// �J
	this->moveIn(rain);
	// ��2D
	this->moveIn(fog2D);
	// ��3D
	this->moveIn(water3D);
	// �}�O�}
	this->moveIn(lava);
	// ��
	this->moveIn(sky);
	// ����
	this->moveIn(tornado);

	// �X�e�[�W�P
	this->moveIn(stg1);
	// �X�e�[�W�Q
	this->moveIn(stg2);
	// �X�e�[�W�R
	this->moveIn(stg3);
	// �X�e�[�W�S
	this->moveIn(stg4);
	// �X�e�[�W�T
	this->moveIn(stg5);
	// �X�e�[�W�U
	this->moveIn(stg6);

	// �{�X�X�e�[�W�P
	this->moveIn(stg1Boss);
	// �{�X�X�e�[�W�Q
	this->moveIn(stg2Boss);
	// �{�X�X�e�[�W�R
	this->moveIn(stg3Boss);
	// �{�X�X�e�[�W�S
	this->moveIn(stg4Boss);
	// �{�X�X�e�[�W�T
	this->moveIn(stg5Boss);
	// �{�X�X�e�[�W�U
	this->moveIn(stg6Boss);
	// �{�X�X�e�[�W�V
	this->moveIn(stg7Boss);

	// �J������Z�����i�s������100�𒴂����珉����Ԃɖ߂�
	if (camera->getPositionZ() < -100) {
		this->resetCameraParam();
	}

	camera->setCamera();
}


void Effect3D::draw(void) {
	float posZ = fabs(camera->getPositionZ());

	// �X�e�[�W�P
	if (stg1.active == true) {
		for (int i = 0; i < 10; i++) {
			if ((i*20 + 10) > posZ && (i*20) < (posZ + 80)) {
				stg1.imageX->drawImage(0,0,0,0,0,i*20);
			}
		}
		for (int i = 0; i < 100; i++) {
			if ((i*16 + 10) > fabs(camera->getPositionZ()) && (i*16) < fabs(camera->getPositionZ()) + 80) {
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0.1,-static_cast<float>(gamemath::toRadian(stg1.frame % 360)),0,0,i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,-static_cast<float>(gamemath::toRadian(stg1.frame % 360)),0,0,8+i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,static_cast<float>(gamemath::toRadian(stg1.frame % 360)),6,0,8+i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,static_cast<float>(gamemath::toRadian(stg1.frame % 360)),6,0,i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,static_cast<float>(gamemath::toRadian(stg1.frame % 360)),-6,0,8+i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,static_cast<float>(gamemath::toRadian(stg1.frame % 360)),-6,0,i*16);
			}
		}
	}

	// �X�e�[�W�Q
	if (stg2.active == true) {
		for (int i = 0; i < 10; i++) {
			if ((i*20 + 10) > posZ && (i*20) < (posZ + 80)) {
				stg2.imageX->drawImage(0,0,0,0,0,i*20);
			}
		}
	}
	// �X�e�[�W�R
	if (stg3.active == true) {
		for (int i = 0; i < 10; i++) {
			if ((i*20 + 10) > posZ && (i*20) < (posZ + 80)) {
				stg3.imageX->drawImage(0,0,0,0,0,i*20);
			}
		}
	}
	// �X�e�[�W�S
	if (stg4.active == true) {
		for (int i = 0; i < 10; i++) {
			if ((i*20 + 10) > posZ && (i*20) < (posZ + 80)) {
				stg4.imageX->drawImage(0,0,0,0,0,i*20);
			} 
		}
		for (int i = 0; i < 100; i++) {
			if ((i*16 + 10) > posZ && (i*16) < posZ + 80) {
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0.1,-static_cast<float>(gamemath::toRadian(stg4.frame % 360)),5,1,i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,-static_cast<float>(gamemath::toRadian(stg4.frame % 360)),5,1,8+i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,static_cast<float>(gamemath::toRadian(stg4.frame % 360)),-3,1,8+i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,static_cast<float>(gamemath::toRadian(stg4.frame % 360)),-3,1,i*16);
			}
		}
		for (int i = 0; i < 20; i++) {
			rain.image->drawImage(
				static_cast<float>(gamemath::toRadian(random(15))),
				random(640),
				random(100) + 180,
				0);
		}
	}
	// �X�e�[�W�T
	if (stg5.active == true) {
		for (int i = 0; i < 10; i++) {
			if ((i*20 + 10) > posZ && (i*20) < (posZ + 80)) {
				stg5.imageX->drawImage(0,0,0,0,0,i*20);
			}
		}
		for (int i = 0; i < 100; i++) {
			if ((i*16 + 10) > posZ && (i*16) < posZ + 80) {
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,-static_cast<float>(gamemath::toRadian(stg5.frame % 360)),3,1,i*16);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,-static_cast<float>(gamemath::toRadian(stg5.frame % 360)),3,1,8+i*16);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,-static_cast<float>(gamemath::toRadian(stg5.frame % 360)),-3,1,i*16);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,-static_cast<float>(gamemath::toRadian(stg5.frame % 360)),-3,1,8+i*16);
			}
		}
	}
	// �X�e�[�W�U
	if (stg6.active == true) {
		for (int i = 0; i < 10; i++) {
			if ((i*20 + 10) > posZ && (i*20) < (posZ + 80)) {
				stg6.imageX->drawImage(0,0,0,0,0,i*20);
			}
		}
	}

	// �{�X�X�e�[�W�P
	if (stg1Boss.active == true) {
		stg1Boss.imageX->drawImage(0,gamemath::toRadian(stg1Boss.frame % 360),0,0,0,0);
	}
	// �{�X�X�e�[�W�Q
	if (stg2Boss.active == true) {
		stg2Boss.imageX->drawImage(0,gamemath::toRadian(stg2Boss.frame % 360),0,0,0,0);
	}
	// �{�X�X�e�[�W�R
	if (stg3Boss.active == true) {
		stg3Boss.imageX->drawImage(0,gamemath::toRadian(stg3Boss.frame % 360),0,0,0,0);
	}
	// �{�X�X�e�[�W�S
	if (stg4Boss.active == true) {
		stg4Boss.imageX->drawImage(0,gamemath::toRadian(stg4Boss.frame % 360),0,0,0,0);

		for (int i = 0; i < 20; i++) {
			rain.image->drawImage(
				static_cast<float>(gamemath::toRadian(random(15))),
				random(640),
				random(100) + 180,
				0);
		}

	}
	// �{�X�X�e�[�W�T
	if (stg5Boss.active == true) {
		stg5Boss.imageX->drawImage(0,0,0,0,0,0);

		for (int i = 0; i < 10; i++) {
			for (int l = 0; l < 10; l++) {
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,-static_cast<float>(gamemath::toRadian(stg5Boss.frame % 360)),i*10 - 50,-1,-l*10 + 50);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,-static_cast<float>(gamemath::toRadian(stg5Boss.frame % 360)),i*10 - 45,-1,-l*10 + 55);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,-static_cast<float>(gamemath::toRadian(stg5Boss.frame % 360)),-i*10 + 50,-1,-l*10 + 50);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(90)),0,-static_cast<float>(gamemath::toRadian(stg5Boss.frame % 360)),-i*10 + 55,-1,-l*10 + 55);
			}
		}
	}
	// �{�X�X�e�[�W�U
	if (stg6Boss.active == true) {
		stg6Boss.imageX->drawImage(0,gamemath::toRadian(stg6Boss.frame % 360),0,0,0,0);
	}
	// �{�X�X�e�[�W�V
	if (stg7Boss.active == true) {
		stg7Boss.imageX->drawImage(0,gamemath::toRadian(stg7Boss.frame % 360),0,0,0,0);
	}


	// ��3D
	if (water3D.active == true) {
		for (int i = 0; i < 100; i++) {
			if ((i*16 + 10) > fabs(camera->getPositionZ()) && (i*16) < fabs(camera->getPositionZ()) + 80) {
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(80)),0,-static_cast<float>(gamemath::toRadian(water3D.frame % 360)),0,0,i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(100)),0,-static_cast<float>(gamemath::toRadian(water3D.frame % 360)),0,0,8+i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(80)),0,static_cast<float>(gamemath::toRadian(water3D.frame % 360)),6,0,8+i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(100)),0,static_cast<float>(gamemath::toRadian(water3D.frame % 360)),6,0,i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(80)),0,static_cast<float>(gamemath::toRadian(water3D.frame % 360)),-6,0,8+i*16);
				water3D.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(100)),0,static_cast<float>(gamemath::toRadian(water3D.frame % 360)),-6,0,i*16);
			}
		}
	}
	// �}�O�}
	if (lava.active == true) {
		for (int i = 0; i < 100; i++) {
			if ((i*16 + 10) > fabs(camera->getPositionZ()) && (i*16) < fabs(camera->getPositionZ()) + 80) {
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(80)),0,-static_cast<float>(gamemath::toRadian(lava.frame % 360)),0,0,i*16);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(100)),0,-static_cast<float>(gamemath::toRadian(lava.frame % 360)),0,0,8+i*16);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(80)),0,static_cast<float>(gamemath::toRadian(lava.frame % 360)),6,0,8+i*16);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(100)),0,static_cast<float>(gamemath::toRadian(lava.frame % 360)),6,0,i*16);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(80)),0,static_cast<float>(gamemath::toRadian(lava.frame % 360)),-6,0,8+i*16);
				lava.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(100)),0,static_cast<float>(gamemath::toRadian(lava.frame % 360)),-6,0,i*16);
			}
		}
	}
	// ����
	if (tornado.active == true) {;
		for (int i = 0; i < 24; i++) {
				tornado.image->drawImageNoCamera(0,static_cast<float>(gamemath::toRadian(i*15)),0,static_cast<int>(14*sin(gamemath::toRadian(i*15))),8,static_cast<int>(14*cos(gamemath::toRadian(i*15))));
				tornado.image->drawImageNoCamera(0,static_cast<float>(gamemath::toRadian(i*15)),0,static_cast<int>(14*sin(gamemath::toRadian(i*15))),0,static_cast<int>(14*cos(gamemath::toRadian(i*15))));
				tornado.image->drawImageNoCamera(0,static_cast<float>(gamemath::toRadian(i*15)),0,static_cast<int>(14*sin(gamemath::toRadian(i*15))),-8,static_cast<int>(14*cos(gamemath::toRadian(i*15))));
				tornado.image->drawImageNoCamera(0,static_cast<float>(gamemath::toRadian(i*15)),0,static_cast<int>(14*sin(gamemath::toRadian(i*15))),-16,static_cast<int>(14*cos(gamemath::toRadian(i*15))));
				tornado.image->drawImageNoCamera(0,static_cast<float>(gamemath::toRadian(i*15)),0,static_cast<int>(14*sin(gamemath::toRadian(i*15))),-24,static_cast<int>(14*cos(gamemath::toRadian(i*15))));
		}
	}

	// ��
	if (sky.active == true) {
		for (int i = 0; i < 100; i++) {
			if ((i*10 + 10) > fabs(camera->getPositionZ()) && (i*10) < fabs(camera->getPositionZ()) + 80) {
				sky.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(45)),static_cast<float>(gamemath::toRadian(90)),0,7,-5,i*10);
				sky.image->drawImageNoCamera(static_cast<float>(gamemath::toRadian(-45)),static_cast<float>(gamemath::toRadian(90)),0,-7,-5,i*10);
			}
		}
	}
	// ��2D
	if (fog2D.active == true) {
		fog2D.image->drawImageNo2D(gamemath::toRadian(60),0,0,0,0,0);
	}
	// �J
	if (rain.active == true) {
		for (int i = 0; i < rain.strength; i++) {
			rain.image->drawImage(
				static_cast<float>(gamemath::toRadian(random(15))),
				random(640),
				random(100) + 180,
				0);
		}
	}
}

int Effect3D::random(int count) {
	return rand() % count;
}


Effect3D* Effect3D::singleton = new Effect3D();