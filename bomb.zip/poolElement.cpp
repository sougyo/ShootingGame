#include "poolElement.h"

using gameutil::PoolElement;

PoolElement::PoolElement(int time) : time(time) {
}

PoolElement::~PoolElement(void) {
}
