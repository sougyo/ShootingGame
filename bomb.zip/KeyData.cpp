#include "KeyData.h"

using namespace gameinpututil;

KeyData::KeyData(void) {
    up = false;
    down = false;
    left = false;
    right = false;

    shot = false;
    bomb = false;
    slow = false;
    skip = false;
    pause = false;
}
