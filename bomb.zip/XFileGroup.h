#ifndef ___XFILEGROUP_H
#define ___XFILEGROUP_H

#include <vector>
#include <string>

#include "XFileInformation.h"

namespace background {
	namespace xfile {
		class XFileGroup;
	}
}

class background::xfile::XFileGroup {
public:
	XFileGroup(const std::vector<const std::string>& xfileList);
	~XFileGroup(void) { finalize(); }
	inline void begin(void) { index = 0; }
	inline bool hasNext(void) { return index < xfileInfo.size(); }
	XFileInformation* next(void) { return xfileInfo[index++]; }
	void finalize(void);
private:
	size_t index;
	std::vector<XFileInformation*> xfileInfo;

	void analyze(const std::string& xfile);
	std::string getArg(const std::string args, int count);
	void push(XFileInformation*);
	float toFloat(std::string str) const;
};

#endif	/* ___XFILEGROUP_H */