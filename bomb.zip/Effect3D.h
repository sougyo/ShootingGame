#ifndef	___EFFECT3D_H
#define	___EFFECT3D_H

#include <d3d9.h>
#include <d3dx9.h>

#include "ImageFactory.h"
#include "EffectInformation.h"
#include "Camera.h"

namespace effect {
	class Effect3D;
}

class effect::Effect3D {
private:
	Effect3D(void);
public:
	~Effect3D(void);

	void initialize(LPDIRECT3DDEVICE9& device);
	void reset(void);
	
	void fire(effect::EffectInformation& effectInfo);
	void setParamater(effect::EffectInformation& effectInfo, int x, int y, int z);
	void move(void);
	void draw(void);

	static Effect3D* getInstance(void)	{ return singleton; };

private:
	void resetCameraParam(void);
	int random(int count);


	LPDIRECT3DDEVICE9 device;

	struct EffectData {
		bool active;
		int strength;
		int frame;
		int x,y,z;
		graphics::Image* image;
		graphics::ImageX* imageX;
	};

	struct CameraData {
		float angleX,angleY,angleZ;
		float movX,movY,movZ;
		float vX,vY,vZ;
		float vangleX,vangleY,vangleZ;
	};

	void setEffectInfo(effect::EffectInformation& effectInfo, EffectData& data);
	void setEffectInfoCamera(effect::EffectInformation& effectInfo, EffectData& data,
		float angleX, float angleY, float angleZ, float movX, float movY, float movZ, float vX, float vY, float vZ);
	void setCameraParam(float angleX, float angleY, float angleZ,
		float movX, float movY, float movZ, float vX, float vY, float vZ, EffectData& data);
	void setCameraParam(float angleX, float angleY, float angleZ,
		float movX, float movY, float movZ, float vX, float vY, float vZ, float vangleX, float vangleY, float vangleZ, EffectData& data);
	void moveIn(EffectData& data);

	EffectData stg1,stg2,stg3,stg4,stg5,stg6;
	EffectData stg1Boss,stg2Boss,stg3Boss,stg4Boss,stg5Boss,stg6Boss,stg7Boss;
	EffectData gansho;
	EffectData rain,fog2D,water3D,lava,sky,tornado;
	CameraData camdata;
	graphics::Camera* camera;

	static Effect3D* singleton;

};

#endif	/*___EFFECT3D_H*/