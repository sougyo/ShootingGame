#ifndef __DIRECTXUTIL_H
#define __DIRECTXUTIL_H

namespace directxutil {
    inline bool isFail(HRESULT result) { return FAILED(result); }
	inline void checkInit(HRESULT result) { if (isFail(result)) exit(1); }
}

#endif // __DIRECTXUTIL_H