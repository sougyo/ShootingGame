#ifndef	___IMAGEX_H
#define	___IMAGEX_H

#include <d3d9.h>
#include <d3dx9.h>

#include <string>
#include <cstdlib>

const static int ROTATE_X = 0;
const static int ROTATE_Y = 1;
const static int ROTATE_Z = 2;

namespace graphics {
	class ImageX;
}

class graphics::ImageX {
public:
	ImageX(LPDIRECT3DDEVICE9& device, const std::string& fileName);
	ImageX(LPDIRECT3DDEVICE9& device, const std::string& fileName, float radX, float radY, float radZ, float movX, float movY, float movZ);
	~ImageX(void);

public:
	void drawImage(void);
	void drawImage(int axis, float rad, float movX, float movY, float movZ);
	void drawImage(float radX, float radY, float radZ, float movX, float movY, float movZ);

	double getRadius(void);
	SIZE getSize(void);
	inline float getZ(void) { return movZ; }

private:
	void initImageX(const std::string& fileName);
	void drawImageIn(void);
	void setTransformAxis(int axis, float rad, float movX, float movY, float movZ);
	void setTransformAll(float radX, float radY, float radZ, float movX, float movY, float movZ);
	void analyzeImageName(const std::string& str);

	LPDIRECT3DDEVICE9	device;
	LPDIRECT3DTEXTURE9*	texture;

	// ���b�V��
	D3DMATERIAL9*		material;
	D3DXMATERIAL*		materials;
	LPD3DXMESH			mesh;			// ID3DXMesh�C���^�[�t�F�C�X�ւ̃|�C���^
	LPD3DXBUFFER		meshBuffer;		// ���b�V���̃}�e���A�������i�[
	DWORD				numMesh;		// �}�e���A�����̑���

	D3DXMATRIX			matrixWorld;	// ���f���̔z�u
	D3DXMATRIX			matrixRad;
	D3DXMATRIX			matrixRadX;
	D3DXMATRIX			matrixRadY;
	D3DXMATRIX			matrixRadZ;
	D3DXMATRIX			matrixMov;
	SIZE				size;

	float movZ;
};

#endif	/*___IMAGE3D_X*/