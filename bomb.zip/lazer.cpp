#include "lazer.h"

using bulletutil::Lazer;

Lazer::Lazer(void) {
}

Lazer::~Lazer(void) {
}