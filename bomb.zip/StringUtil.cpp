#include "StringUtil.h"

#include <cstdlib>

using namespace lang::util;

std::string StringUtil::substring(const std::string& str, size_t start, size_t end) {
	return str.substr(start, end - start);
}

int StringUtil::indexOf(const std::string& str, char ch) {
	return static_cast<int>(str.find(ch));
}

int StringUtil::indexOf(const std::string& src, const std::string& str) {
	return static_cast<int>(src.find(str));
}

std::string StringUtil::trim(const std::string& str) {
	std::string newStr = "";
	bool wasNotSpace = false;
	for (unsigned int i = 0; i < str.length(); i++) {
		if (!isWhiteSpace(str[i])) {
			newStr += str[i];
			wasNotSpace = true;
		} else if (wasNotSpace) {
			if (!isLineNew(str[i])) newStr += str[i];
		}
	}
	return newStr;
}

bool StringUtil::isWhiteSpace(char ch) {
	return ch == ' ' || ch == '\t' || isLineNew(ch);
}

bool StringUtil::isLineNew(char ch) {
	return ch == '\r' || ch == '\n';
}

bool StringUtil::equals(const std::string& str1, const std::string& str2) {
	return str1 == str2;
}

int StringUtil::toInteger(const std::string& str) {
	return atoi(str.c_str());
}

long StringUtil::toLong(const std::string& str) {
	return atol(str.c_str());
}

float StringUtil::toFloat(const std::string& str) {
	return static_cast<float>(toDouble(str));
}

double StringUtil::toDouble(const std::string& str) {
	return atof(str.c_str());
}

bool StringUtil::startsWith(const std::string& src, const std::string& str) {
	for (unsigned int i = 0; i < str.length(); i++)
		if (src[i] != str[i]) return false;
	return true;
}

bool StringUtil::endsWith(const std::string& src, const std::string& str) {
	for (unsigned int i = 0; i < str.length(); i++)
		if (src[src.length() - i] != str[str.length() - i]) return false;
	return true;
}

std::string StringUtil::addStr(const std::string& origin, const std::string& def, bool isCheck) {
	if (isCheck) {
		if (endsWith(origin, def)) return origin;
		else return origin + def;
	}
	return origin + def;
}