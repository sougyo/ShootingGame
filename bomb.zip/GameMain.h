#ifndef ___GAME_MAIN_H
#define ___GAME_MAIN_H

#include "keyStoreElement.h"
#include "state/DisplayState.h"
#include "state/GameTitle.h"
#include "state/DisplayStateMap.h"

namespace gamesystem {
	class GameMain;
}

class gamesystem::GameMain {
private:
	gamestate::DisplayState* displayState;
	gamesystem::KeyStoreElement prevKeyStoreElement;
	gamesystem::KeyStoreElement currentKeyStoreElement;

private:
	GameMain(gamesystem::GameMain&);
	gamesystem::GameMain& operator=(gamesystem::GameMain);

public:
	GameMain(void);
	~GameMain(void);

public:
	void move(void);
	void draw(void);
	void setKeyData(gamesystem::KeyStoreElement);
};


#endif // ___GAME_MAIN_H