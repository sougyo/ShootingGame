#ifndef ___GRAPHIC_H
#define ___GRAPHIC_H

#include<d3d9.h>
#include<d3dx9.h>

#include "ImageFactory.h"
#include "Camera.h"
#include "Effect3D.h"
#include "FontFactory.h"

namespace graphics {
	class Graphic;
}

class graphics::Graphic {
public:
	Graphic(void);
	~Graphic(void);

public:
	//DirectGraphic�֌W
	HRESULT initialize(HWND windowHandle, int clientWidth, int clientHeight);
	LPDIRECT3DDEVICE9 getDevice(void);
	void finalize(void);
	HRESULT begin(void);
	void end(void);

	//�J����
private:
	void setCamera(void);
public:
	void rotateCamera(double angle);
	void setPosition(D3DXVECTOR3& position);
	void setDirection(D3DXVECTOR3& direction);
	void setGradient(D3DXVECTOR3& gradient);
	D3DXVECTOR3 getPosition(void);
	D3DXVECTOR3 getDirection(void);
	D3DXVECTOR3 getGradient(void);

	//Sprite�֌W
	void spriteBegin(void);
	void spriteEnd(void);

private:
	LPDIRECT3D9				direct3D;
	LPDIRECT3DDEVICE9		device;
	D3DPRESENT_PARAMETERS	param;
	LPD3DXSPRITE			sprite;

	graphics::Camera* camera;
};

#endif	/* ___GRAPHIC_H */