#include "Camera.h"
#include "gameMath.h"

#include <cmath>

using namespace graphics;

Camera::Camera(void): angleX(0), angleY(0), angleZ(0), x(0), y(0), z(0),
vX(0), vY(0), vZ(0), vangleX(0), vangleY(0), vangleZ(0), radX(0), radY(0), radZ(0) {
}
void Camera::initialize(LPDIRECT3DDEVICE9& device) {
	this->device = device;

	D3DXMatrixIdentity(&matrixWorld);
	D3DXMatrixRotationYawPitchRoll(&matrixRad, -radY, -radX, -radZ);
	D3DXMatrixTranslation(&matrixMov, x, y, z);

	//--------------------------------------
	// �r���[�C���O�s��̏�����
	//--------------------------------------

	D3DXVECTOR3	position(0,0,0);
	D3DXVECTOR3	direction(0,0,1);
	D3DXVECTOR3	gradient(0,1,0);

	D3DXMatrixIdentity(&matrixView);
	D3DXMatrixLookAtLH(&matrixView, 
						&position,
						&direction,
						&gradient);

	//--------------------------------------
	// ���W�ϊ��i�J�����̐ݒ�Ȃǁj
	//--------------------------------------

	// �r���[�|�[�g�̎擾
	D3DVIEWPORT9 vp;
	if(FAILED(device->GetViewport(&vp))) {
		return;
	}

	// �A�X�y�N�g��̌v�Z
	float aspect;
	aspect = (float)vp.Width / (float)vp.Height;

	// �ˉe�s��̏�����
	D3DXMatrixIdentity(&projection);
	D3DXMatrixPerspectiveFovLH(&projection, D3DXToRadian(45.0f), aspect, 1.0f, 1000.0f);

	// �ˉe�s��̐ݒ�
	device->SetTransform(D3DTS_PROJECTION, &projection);

	// �J�����̐ݒ�
	device->SetTransform(D3DTS_VIEW, &matrixView);
	this->setCamera();
}

Camera::~Camera(void) {
}



void Camera::setVelocity(float vX, float vY, float vZ) {
	this->vX = vX;
	this->vY = vY;
	this->vZ = vZ;
}
void Camera::addVelocity(float vX, float vY, float vZ) {
	this->vX += vX;
	this->vY += vY;
	this->vZ += vZ;
}

void Camera::updateVelocity(void) {
	x += vX;
	y += vY;
	z += vZ;
	angleX += vangleX;
	angleY += vangleY;
	angleZ += vangleZ;
	this->rotateCamera();
	D3DXMatrixTranslation(&matrixMov, x, y, z);
}


void Camera::setPosition(float movX, float movY, float movZ) {
	this->x = movX;
	this->y = movY;
	this->z = movZ;
	D3DXMatrixTranslation(&matrixMov, x, y, z);
}
void Camera::addPosition(float movX, float movY, float movZ) {
	this->x += movX;
	this->y += movY;
	this->z += movZ;
	D3DXMatrixTranslation(&matrixMov, x, y, z);
}


void Camera::setRotateCamera(float angleX, float angleY, float angleZ) {
	this->angleX = angleX;
	this->angleY = angleY;
	this->angleZ = angleZ;
	this->rotateCamera();
}
void Camera::addRotateCamera(float angleX, float angleY, float angleZ) {
	this->angleX += angleX;
	this->angleY += angleY;
	this->angleZ += angleZ;
	this->rotateCamera();
}

void Camera::addRotateCameraRad(float radX, float radY, float radZ) {
	this->addRotateCamera(
		static_cast<float>(gamemath::toDegree(radX)),
		static_cast<float>(gamemath::toDegree(radY)),
		static_cast<float>(gamemath::toDegree(radZ))
		);
}

void Camera::setVelocityRotateCamera(float vangleX, float vangleY, float vangleZ) {
	this->vangleX = vangleX;
	this->vangleY = vangleY;
	this->vangleZ = vangleZ;
}

void Camera::rotateCamera(void) {
	this->radX = static_cast<float>(gamemath::toRadian(this->angleX));
	this->radY = static_cast<float>(gamemath::toRadian(this->angleY));
	this->radZ = static_cast<float>(gamemath::toRadian(this->angleZ));
	D3DXMatrixRotationYawPitchRoll(&matrixRad, -radY, -radX, -radZ);
}


void Camera::setCamera(void) {
	this->updateVelocity();
	D3DXMatrixIdentity(&matrixWorld);
	D3DXMatrixMultiply(&matrixWorld, &matrixMov, &matrixRad);
	device->SetTransform(D3DTS_VIEW, &matrixWorld);
}

void Camera::setAllCamera(float angleX, float angleY, float angleZ, float movX, float movY, float movZ) {
	this->addPosition(movX,movY,movZ);
	this->addRotateCamera(angleX,angleY,angleZ);
	this->setCamera();
}

void Camera::resetCamera(void) {
	this->angleX = 0;
	this->angleY = 0;
	this->angleZ = 0;
	this->radX = 0;
	this->radY = 0;
	this->radZ = 0;
	this->x = 0;
	this->y = 0;
	this->z = 0;
	this->vX = 0;
	this->vY = 0;
	this->vZ = 0;
	this->vangleX = 0;
	this->vangleY = 0;
	this->vangleZ = 0;
}

Camera* Camera::singleton = new Camera();