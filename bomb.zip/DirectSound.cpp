#include "DirectSound.h"

using namespace gamesoundutil;
using namespace directxutil;

#include <cstdlib>
#include <fstream>

DirectSound::DirectSound(void){
	soundManager = new CSoundManager();
	soundBGM = 0;
	
	NSE_NUM = 4;
	GSE_NUM = 8;
	
	trackNum = 0;
    prevTrackNum = 0;
	isPausing_ = false;
	volumeBGM = 0;
	volumeSE = 0; 
}

DirectSound::~DirectSound(void) {
	for (int i = 0; i < NSE_NUM; i++)
		if (soundNormalSE[i] != 0) delete soundNormalSE[i];

	for (int i = 0; i < GSE_NUM; i++)
		if (soundGameSE[i] != 0) delete soundGameSE[i];

	if (soundBGM != 0) delete soundBGM;
	if (soundManager != 0) delete soundManager;

	delete[] isGameSEPausing_;
	delete[] trackNamesSE;
	delete[] trackNamesBGM;
}

bool DirectSound::initInstance(HWND wndApp) {
	HRESULT result;

	result = soundManager->Initialize(wndApp, DSSCL_PRIORITY);
	checkInit(result);
	
	result = soundManager->SetPrimaryBufferFormat(CHANNELS, SAMPLINGRATE, BITRATE);
	checkInit(result);

	if (!initFileName()) return false;
	initSE();

	return true;
}

bool DirectSound::initFileName(void) {
	std::ifstream in("music.dat");
	if (!in) return false;

	while (!in.eof()) {
		std::vector<std::string> temp(3);
		in >> temp[0];
		in >> temp[1];
		in >> temp[2];

		if (temp[0] != "") musicInfo.push_back(temp);
	}

	BGM_NUM = static_cast<int>(musicInfo.size());

	trackNamesBGM = new std::string[BGM_NUM];
	for (int i = 0; i < BGM_NUM; i++) {
		trackNamesBGM[i] = "./BGM/";
		trackNamesBGM[i] += musicInfo[i][0];
	}

	trackNamesSE = new std::string[NSE_NUM+GSE_NUM];
	for (int i = 0; i < NSE_NUM + GSE_NUM; i++) {
		trackNamesSE[i] = "./SE/s";
		char temp[3];
		trackNamesSE[i] += itoa(i+1, temp, 10);
		trackNamesSE[i] += ".wav";
	}

	soundNormalSE = new CSound*[NSE_NUM];
	soundGameSE = new CSound*[GSE_NUM];
    isGameSEPausing_ = new bool[GSE_NUM];

	for (int i = 0; i < GSE_NUM; i++) isGameSEPausing_[i] = false;
	for (int i = 0; i < NSE_NUM; i++) soundNormalSE[i] = 0;
	for (int i = 0; i < GSE_NUM; i++) soundGameSE[i] = 0;

	return true;
}

void DirectSound::initSE(void) {
	HRESULT result;
	WCHAR fileName[32];

	for (int i = 0; i < NSE_NUM; i++) {
		MultiByteToWideChar(CP_ACP, 0, trackNamesSE[i].c_str(), -1, fileName, MAX_PATH);
		result = soundManager->Create(&soundNormalSE[i], fileName, DSBCAPS_CTRLVOLUME, GUID_NULL, OVERLAPNUM);
		checkInit(result);
	}
   	for (int i = 0; i < GSE_NUM; i++) {
		MultiByteToWideChar(CP_ACP, 0, trackNamesSE[NSE_NUM+i].c_str(), -1, fileName, MAX_PATH);
		result = soundManager->Create(&soundGameSE[i], fileName, DSBCAPS_CTRLVOLUME, GUID_NULL, OVERLAPNUM);
		checkInit(result);
	}
}

bool DirectSound::setTrack(int trackNum) {
	HRESULT result;
	WCHAR fileName[32];

    if (trackNum >= BGM_NUM) return false;

	if (soundBGM != 0) {
		if (soundBGM->IsSoundPlaying()) soundBGM->Stop();
		delete soundBGM;
		soundBGM = 0;
	}

	MultiByteToWideChar(CP_ACP, 0, trackNamesBGM[trackNum].c_str(), -1, fileName, MAX_PATH);
	result = soundManager->Create(
        &soundBGM, fileName, DSBCAPS_CTRLVOLUME, GUID_NULL);
	if (isFail(result)) return false;

    this->prevTrackNum = this->trackNum;
	this->trackNum = trackNum;

	return true;
}

int DirectSound::getNextTrack(void) {
    switch (trackNum) {
        case 0:
            return 1;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            return 7;
        case 6:
            return 8;
        case 7:
            return (prevTrackNum + 1);
        case 8:
            return 9;
        case 9:
            return 10;
        default:
            return 0;
    }
}

bool DirectSound::play(void) {
	HRESULT result;
	if (soundBGM == 0) return false;

	result = soundBGM->Play(0, DSBPLAY_LOOPING, volumeBGM);
	if (isFail(result)) return false;

    for (int i = 0; i < GSE_NUM; i++) {
        if (isGameSEPausing_[i]) {
            result = soundGameSE[i]->Play(0, 0, volumeSE);
	        if (isFail(result)) return false;
        }
    }

    isPausing_ = false;

	return true;
}

bool DirectSound::pause(void) {
	HRESULT result;
	if (soundBGM == 0) return false;

	result = soundBGM->Stop();
	if (isFail(result)) return false;

    for (int i = 0; i < GSE_NUM; i++) {
        isGameSEPausing_[i] = false;
        if (soundGameSE[i]->IsSoundPlaying()) {
            isGameSEPausing_[i] = true;
            result = soundGameSE[i]->Stop();
	        if (isFail(result)) return false;
        }
    }

    isPausing_ = true;

	return true;
}

bool DirectSound::stop(void) {
	HRESULT result;
	if (soundBGM == 0) return false;

	result = soundBGM->Stop();
	if (isFail(result)) return false;

	result = soundBGM->Reset();
	if (isFail(result)) return false;

    for (int i = 0; i < GSE_NUM; i++) {
        isGameSEPausing_[i] = false;
        if (soundGameSE[i]->IsSoundPlaying()) {
            result = soundGameSE[i]->Stop();
	        if (isFail(result)) return false;

            result = soundGameSE[i]->Reset();
    	    if (isFail(result)) return false;
        }
    }

    isPausing_ = false;

	return true;
}

bool DirectSound::playNormalSE(int trackNum) {
    HRESULT result;

    if (trackNum >= NSE_NUM) return false;
	if (soundNormalSE[trackNum] == 0) return false;

	result = soundNormalSE[trackNum]->Play(0, 0, volumeSE);
	if (isFail(result)) return false;

	return true;
}

bool DirectSound::playGameSE(int trackNum) {
    HRESULT result;

    if (trackNum >= GSE_NUM) return false;
	if (soundGameSE[trackNum] == 0) return false;

	result = soundGameSE[trackNum]->Play(0, 0, volumeSE);
	if (isFail(result)) return false;

	return true;
}

bool DirectSound::isBGMPlaying(void) const {
	if (soundBGM == 0) return false;
	return (soundBGM->IsSoundPlaying() != 0);
}

bool DirectSound::isNormalSEPlaying(int trackNum) const {
    if (soundNormalSE[trackNum] == 0) return false;
	return (soundNormalSE[trackNum]->IsSoundPlaying() != 0);
}

bool DirectSound::isGameSEPlaying(int trackNum) const {
    if (soundGameSE[trackNum] == 0) return false;
	return (soundGameSE[trackNum]->IsSoundPlaying() != 0);
}


bool DirectSound::incBGMVolume(void) {
	HRESULT result;

    if (volumeBGM > DSBVOLUME_MAX - VOLUMEINTERVAL) volumeBGM = DSBVOLUME_MAX;
    else if (volumeBGM < DSBVOLUME_MIN / 2) volumeBGM = DSBVOLUME_MIN / 2;
    else volumeBGM += VOLUMEINTERVAL;

	if (isBGMPlaying()) {
		result = soundBGM->Play(0, DSBPLAY_LOOPING, volumeBGM);
		if (isFail(result)) return false;
	}

    return true;
}

bool DirectSound::decBGMVolume(void) {
	HRESULT result;

    if (volumeBGM > DSBVOLUME_MAX) volumeBGM = 0;
    else if (volumeBGM < DSBVOLUME_MIN / 2 + VOLUMEINTERVAL) volumeBGM = DSBVOLUME_MIN / 2;
    else volumeBGM -= VOLUMEINTERVAL;

	if (isBGMPlaying()) {
		result = soundBGM->Play(0, DSBPLAY_LOOPING, volumeBGM);
		if (isFail(result)) return false;
	}

    return true;
}

bool DirectSound::incSEVolume(void) {
    if (volumeSE > DSBVOLUME_MAX - VOLUMEINTERVAL) volumeSE = 0;
    else if (volumeSE < DSBVOLUME_MIN / 2) volumeSE = DSBVOLUME_MIN / 2;
    else volumeSE += VOLUMEINTERVAL;

    return true;
}

bool DirectSound::decSEVolume(void) {
    if (volumeSE > DSBVOLUME_MAX) volumeSE = 0;
    else if (volumeSE < DSBVOLUME_MIN / 2 + VOLUMEINTERVAL) volumeSE = DSBVOLUME_MIN / 2;
    else volumeSE -= VOLUMEINTERVAL;

    return true;
}

void DirectSound::resetVolume(void) {
	volumeBGM = 0;
	volumeSE = 0;
    incBGMVolume();
    incSEVolume();
}

DirectSound* DirectSound::directSoundSingleton = new DirectSound();

