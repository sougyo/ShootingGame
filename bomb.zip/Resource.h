#ifndef	___RESOURCE_H
#define	___RESOURCE_H

namespace effect {
	namespace field {
		const int RAIN		= 0;
		const int FOG_2D	= 1;
		const int FOG_3D	= 2;
		const int FIRE_3D	= 3;
		const int WATER		= 4;
	}
	namespace part {
		const int OWN_SHIELD	= 101;
		const int BOSS_EFFECT	= 102;
	}
}

#endif	/*___RESOURCE_H*/