#include "Image.h"

#include <cmath>

using namespace graphics;

Image::Image(LPDIRECT3DDEVICE9& device, const std::string& fileName) {
	this->initalizeImage(device,fileName,0);
}

Image::Image(LPDIRECT3DDEVICE9& device, const std::string& fileName, float alpha) {
	this->initalizeImage(device,fileName,alpha);
}

void Image::initalizeImage(LPDIRECT3DDEVICE9& device, const std::string& fileName, float alpha) {
	this->device = device;
	this->analyzeImageName(fileName);

	D3DXMatrixIdentity(&matrixWorldX);
	D3DXMatrixIdentity(&matrixWorldY);
	D3DXMatrixIdentity(&matrixWorldZ);

	camera = Camera::getInstance();

	// �I�u�W�F�N�g��VertexBuffer�𐶐�

	// 4�̒��_����Ȃ�VertexBuffer�����
	device->CreateVertexBuffer( 4*sizeof(MY_VERTEX),
		D3DUSAGE_WRITEONLY,
		MY_VERTEX_FVF,
		D3DPOOL_MANAGED, &vertexBuffer, NULL);

    //VertexBuffer�̒��g�𖄂߂�
    vertexBuffer->Lock( 0, 0, (void**)&v, 0 );
    
	float hoge = 117;
    // ���_���W�̐ݒ�
	v[0].position = D3DXVECTOR3(-size.cx/hoge,  size.cy/hoge, 0.0f );
	v[1].position = D3DXVECTOR3( size.cx/hoge,  size.cy/hoge, 0.0f );
    v[2].position = D3DXVECTOR3(-size.cx/hoge, -size.cy/hoge, 0.0f );
    v[3].position = D3DXVECTOR3( size.cx/hoge, -size.cy/hoge, 0.0f );

	// �e�N�X�`�����W�̐ݒ�
    v[0].texture = D3DXVECTOR2(0.0f,0.0f);
    v[1].texture = D3DXVECTOR2(1.0f,0.0f);
    v[2].texture = D3DXVECTOR2(0.0f,1.0f);
    v[3].texture = D3DXVECTOR2(1.0f,1.0f);

	// ���_�J���[�̐ݒ�
    v[0].color = v[1].color = v[2].color = v[3].color = D3DXCOLOR(1.0f,1.0f,1.0f,alpha);
    vertexBuffer->Unlock();

	//--------------------------------------
	// �e�N�X�`���摜�̓ǂݍ���
	//--------------------------------------
	if(D3DXCreateTextureFromFileEx(device, fileName.c_str(), 0, 0, 0, 0,
		D3DFMT_A8R8G8B8,
		D3DPOOL_MANAGED,
		D3DX_FILTER_LINEAR,
		D3DX_FILTER_LINEAR,
		D3DCOLOR_XRGB(0,0,0),
		NULL,
		NULL,
		&texture)){
			::MessageBox(NULL,"�t�@�C�������݂��܂���",fileName.c_str(),MB_OK);
		}
}


Image::~Image(void)
{
}

void Image::drawImage(double rad, int movX, int movY) {
	drawImage(-static_cast<float>(rad), movX, movY, 0);
}

//�@�`��@�Q�������W�ϊ��i�Q�����{�J�����O���ϊ��j
void Image::drawImage(double rad, int movX, int movY, int movZ) {
	this->setTransformZ(static_cast<float>(rad),movX,movY,movZ);
	this->drawImageIn();
}
void Image::drawImage(double radX, double radY, double radZ, int movX, int movY, int movZ) {
	this->setTransformAll(static_cast<float>(radX),static_cast<float>(radY),static_cast<float>(radZ),movX,movY,movZ);
	this->drawImageIn();
}

//�@�`��@�R�������W�ϊ�
void Image::drawImageNoCamera(float radX, float radY, float radZ, int movX, int movY, int movZ) {
	this->setTransformNoCamera(radX,radY,radZ,movX,movY,movZ);
	this->drawImageIn();
}

//�@�`��@�R�����{�J�����O���֕ϊ�
void Image::drawImageNo2D(float radX, float radY, float radZ, int movX, int movY, int movZ) {
	this->setTransformNo2D(radX,radY,radZ,movX,movY,movZ);
	this->drawImageIn();
}


void Image::drawImageIn(void){
	device->SetTransform(D3DTS_WORLD,&matrixWorld);

	//--------------------------------------
	// �e�N�X�`���X�e�[�W�̐ݒ�
	//--------------------------------------
	// �J���[�����̐ݒ�
	device->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1);
	device->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );

	// �A���t�@�����̐ݒ�
	device->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
    device->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	device->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_CURRENT );
	
	//--------------------------------------
	// �u�����f�B���O���[�h�̐ݒ�
	//--------------------------------------
    device->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
	device->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
    device->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );

	// �e�N�X�`�����p�C�v���C���ɃZ�b�g
	device->SetTexture( 0, texture);

	// VertexBuffer�̕`��
    device->SetStreamSource( 0, vertexBuffer, 0, sizeof(MY_VERTEX) );
    device->SetFVF( MY_VERTEX_FVF );
    device->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2 );
}

//�@���W�ϊ��@�Q�������W
void Image::setTransformZ(float rad, int movX, int movY, int movZ) {
	this->setTransformAll(0,0,rad,movX,movY,movZ);
}
void Image::setTransformAll(float radX, float radY, float radZ, int movX, int movY, int movZ) {
	D3DXMatrixRotationYawPitchRoll(&matrixRad, radY, radX, radZ);
	D3DXMatrixTranslation(
		&matrixMov,
		static_cast<FLOAT>(movX/58.3f - 5.5),
		static_cast<FLOAT>(-movY/58.5f + 4.1),
		static_cast<FLOAT>(movZ + 10));
	D3DXMatrixMultiply(&matrixWorld, &matrixRad, &matrixMov);

	D3DXMatrixRotationX(&matrixWorldX, camera->getRadX());
	D3DXMatrixRotationY(&matrixWorldY, camera->getRadY());
	D3DXMatrixRotationZ(&matrixWorldZ, camera->getRadZ());

	if (camera->getRadX() == 0) {
		matrixWorld *= matrixWorldY * matrixWorldZ;
	}
	else if (camera->getRadY() == 0) {
		matrixWorld *= matrixWorldX * matrixWorldZ;
	}
	else if (camera->getRadZ() == 0) {
		matrixWorld *= matrixWorldY * matrixWorldX;
	}


	D3DXMatrixTranslation(
		&matrixMov,
		-camera->getPositionX(),
		-camera->getPositionY(),
		-camera->getPositionZ());
	D3DXMatrixMultiply(&matrixWorld, &matrixWorld, &matrixMov);
}

//�@�R�����{�J�����O���֕ϊ�
void Image::setTransformNo2D(float radX, float radY, float radZ, int movX, int movY, int movZ) {
	D3DXMatrixRotationYawPitchRoll(&matrixRad, radY, radX, radZ);
	D3DXMatrixTranslation(
		&matrixMov,
		static_cast<FLOAT>(movX),
		static_cast<FLOAT>(-movY),
		static_cast<FLOAT>(movZ - camera->getPositionZ()));
	D3DXMatrixMultiply(&matrixWorld, &matrixRad, &matrixMov);
}

//�@���W�ϊ��@�R�������W
void Image::setTransformNoCamera(float radX, float radY, float radZ, int movX, int movY, int movZ) {
	D3DXMatrixRotationYawPitchRoll(&matrixRad, radY, radX, radZ);
	D3DXMatrixTranslation(
		&matrixMov,
		static_cast<FLOAT>(movX),
		static_cast<FLOAT>(-movY),
		static_cast<FLOAT>(movZ));
	D3DXMatrixMultiply(&matrixWorld, &matrixRad, &matrixMov);
}


void Image::analyzeImageName(const std::string& str) {
	int firstIndex	= static_cast<int>(str.find('('));
	int secondIndex = static_cast<int>(str.find(','));
	int thirdIndex	= static_cast<int>(str.find(')'));
	if (firstIndex >= secondIndex || secondIndex >= thirdIndex) {
		size.cx = 10;
		size.cy = 10;
		return;
	}
	std::string sub1 = str.substr(firstIndex+1, secondIndex-firstIndex-1);
	std::string sub2 = str.substr(secondIndex+1, thirdIndex-secondIndex-1);
	if (sub1.empty() || sub2.empty() || sub1.find_first_not_of("0123456789") != sub1.npos || sub2.find_first_not_of("0123456789") != sub2.npos) {
		size.cx = 10;
		size.cy = 10;
		return;
	}
	
	int width = atoi(sub1.c_str());
	int height = atoi(sub2.c_str());

	size.cx = width;
	size.cy = height;
}


int Image::getRadius(void) {
	return (size.cx < size.cy) ? size.cx/2 : size.cy/2;
}

SIZE Image::getSize(void) {
	return size;
}