#include "EffectGroup.h"

#include "StringUtil.h"

using namespace background::effect;

EffectGroup::EffectGroup(const std::vector<const std::string>& effectList) {
	for (unsigned int i = 0; i < effectList.size(); i++)
		analyze(effectList[i]);
	frameSum = 0;
	for (unsigned int i = 0; i < effectInfo.size(); i++)
		frameSum += effectInfo[i]->getFrame();
}

::effect::EffectInformation* EffectGroup::getEffect(unsigned long crntFrame) const {
	int index = 0;
	if (frameSum == 0) return 0;
	int frame = crntFrame % frameSum;
	for (unsigned int i = 0; i < effectInfo.size(); i++, index++) {
		frame -= effectInfo[i]->getFrame();
		if (frame < 0) break;
	}
	return this->effectInfo[index];
}

void EffectGroup::finalize(void) {
	for (unsigned int i = 0; i < effectInfo.size(); ++i) {
		delete effectInfo.at(i);
	}
	effectInfo.clear();
}

void EffectGroup::analyze(const std::string& effect) {
	using ::effect::EffectInformation;
	using lang::util::StringUtil;
	std::string eff = StringUtil::substring(effect, 0, StringUtil::indexOf(effect, ' '));
	int type;
	if		(eff == "rain")		type = EffectInformation::RAIN;
	else if (eff == "fog")		type = EffectInformation::FOG_3D;
	else if (eff == "fire")		type = EffectInformation::FIRE_3D;
	else if (eff == "water")	type = EffectInformation::WATER_3D;
	else if (eff == "stg1")	type = EffectInformation::STG1;
	else if (eff == "stg2")	type = EffectInformation::STG2;
	else if (eff == "stg3")	type = EffectInformation::STG3;
	else if (eff == "stg4")	type = EffectInformation::STG4;
	else if (eff == "stg5")	type = EffectInformation::STG5;
	else if (eff == "stg6")	type = EffectInformation::STG6;
	else if (eff == "stg1boss")	type = EffectInformation::STG1_BOSS;
	else if (eff == "stg2boss")	type = EffectInformation::STG2_BOSS;
	else if (eff == "stg3boss")	type = EffectInformation::STG3_BOSS;
	else if (eff == "stg4boss")	type = EffectInformation::STG4_BOSS;
	else if (eff == "stg5boss")	type = EffectInformation::STG5_BOSS;
	else if (eff == "stg6boss")	type = EffectInformation::STG6_BOSS;
	else if (eff == "stg7boss")	type = EffectInformation::STG7_BOSS;
	else						type = EffectInformation::NO_EFFECT;
	int strength;
	int frame;
	if (true || type != EffectInformation::NO_EFFECT) {
		strength = atoi(
			StringUtil::substring(effect, StringUtil::indexOf(effect, ' ') + 1, StringUtil::indexOf(effect, ',')).c_str());
		frame = atoi(
			StringUtil::substring(effect, StringUtil::indexOf(effect, ',') + 1, effect.length()).c_str());
		push(new ::effect::EffectInformation(type, strength, frame));
	} else {
		frame = atoi(StringUtil::substring(effect, eff.length() + 1, effect.length()).c_str());
		push(new ::effect::EffectInformation(type, 0, frame));
	}
}

void EffectGroup::push(::effect::EffectInformation* info) {
	effectInfo.push_back(info);
}