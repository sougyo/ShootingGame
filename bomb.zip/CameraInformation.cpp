#include "CameraInformation.h"

using namespace background::camera;

CameraInformation::CameraInformation(float deltaX, float deltaY, float deltaZ,
		float deltaRadX, float deltaRadY, float deltaRadZ, long frame) {
	this->deltaX = deltaX;
	this->deltaY = deltaY;
	this->deltaZ = deltaZ;
	this->deltaRadX = deltaRadX;
	this->deltaRadY = deltaRadY;
	this->deltaRadZ = deltaRadZ;
	this->frame = frame;
}