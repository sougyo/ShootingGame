#ifndef	___IMAGE_H
#define	___IMAGE_H

#include <d3d9.h>
#include <d3dx9.h>

#include <string>
#include <cstdlib>

#include "Camera.h"

namespace graphics {
	class Image;
}

class graphics::Image {
public:
	Image(LPDIRECT3DDEVICE9& device, const std::string& fileName);
	Image(LPDIRECT3DDEVICE9& device, const std::string& fileName, float alpha);
	~Image(void);

public:
	void drawImage(double rad, int movX, int movY);
	void drawImage(double rad, int movX, int movY, int movZ);
	void drawImage(double radX, double radY, double radZ, int movX, int movY, int movZ);
	void drawImageNoCamera(float radX, float radY, float radZ, int movX, int movY, int movZ);
	void drawImageNo2D(float radX, float radY, float radZ, int movX, int movY, int movZ);
	int  getRadius(void);
	SIZE getSize(void);

private:
	void initalizeImage(LPDIRECT3DDEVICE9& device, const std::string& fileName, float alpha);
	void drawImageIn(void);
	void setTransformZ(float rad, int movX, int movY, int movZ);
	void setTransformAll(float radX, float radY, float radZ, int movX, int movY, int movZ);
	void setTransformNoCamera(float radX, float radY, float radZ, int movX, int movY, int movZ);
	void setTransformNo2D(float radX, float radY, float radZ, int movX, int movY, int movZ);
	void analyzeImageName(const std::string& str);

	LPDIRECT3DDEVICE9	device;
	LPDIRECT3DTEXTURE9	texture;

	D3DXMATRIX				matrixRad;
	D3DXMATRIX				matrixRadX;
	D3DXMATRIX				matrixRadY;
	D3DXMATRIX				matrixRadZ;
	D3DXMATRIX				matrixMov;
	D3DXMATRIX				matrixNew;
	D3DXMATRIX				matrixWorld;
	D3DXMATRIX				matrixWorldX;
	D3DXMATRIX				matrixWorldY;
	D3DXMATRIX				matrixWorldZ;

	LPDIRECT3DVERTEXBUFFER9	vertexBuffer;

	float rad;
	SIZE size;

	Camera* camera;

	// ���_�P�̃f�[�^�^
	struct MY_VERTEX{
		D3DXVECTOR3 position;	// �ʒu
		DWORD		color;		// �F
		D3DXVECTOR2 texture;	// �e�N�X�`���[�̉摜�̈ʒu
	};

	MY_VERTEX* v;

	// �e�u�e�̐ݒ�
	#define MY_VERTEX_FVF  (D3DFVF_XYZ | D3DFVF_DIFFUSE  | D3DFVF_TEX1)
};

#endif	/*___IMAGE_H*/