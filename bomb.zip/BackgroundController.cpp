#include "BackgroundController.h"

using namespace background;

#include "CameraInformation.h"
#include "EffectInformation.h"

#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "dxerr9.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "odbc32.lib")
#pragma comment(lib, "odbccp32.lib")
#pragma comment(lib, "winmm.lib")

//
BackgroundController* BackgroundController::singleton = new BackgroundController();

BackgroundController::BackgroundController(void) {
	//interpreter = BackgroundInterpreter::getInstance();
	//eff = ::effect::Effect3D::getInstance();
}

void BackgroundController::load(int stageNo) {
	std::string fileName;
	fileName = ('0' + stageNo);
	fileName += ".stg";
	load(fileName);
}

void BackgroundController::load(std::string fileName){
	interpreter = BackgroundInterpreter::getInstance();
	//interpreter->finalize();
	eff = ::effect::Effect3D::getInstance();
	interpreter->interpret(fileName);
	distanceZ = 100;

	graphics::ImageFactory* fact = graphics::ImageFactory::getInstance();
	xfile::XFileGroup* xfiles = interpreter->getXFiles();
	for (xfiles->begin(); xfiles->hasNext(); ) {
		xfile::XFileInformation* info = xfiles->next();
		// TODO : X-File�̕`�揀��
		graphics::ImageX* temp = fact->createImageX(info);
		xFiles.push_back(temp);
		temp = fact->createImageX(
			info->getFileName(),
			info->getRadX(),
			info->getRadY(),
			info->getRadZ(),
			info->getX(),
			info->getY(),
			info->getZ() + distanceZ
			);
		xFiles.push_back(temp);
	}
	// TODO : distanceZ���v�Z����B�S�������΂����قǒP���ł͂Ȃ����Ƃɒ��ӁB���[�v���ł���Ă������B
	// �S���������Ȃ��Ă��Ō��X-File�̈ʒu��Z�����ւ̒���������Ζ��Ȃ��B
	//distanceZ = 100;
}

#include "FileOutput4Debug.h"
#include <cmath>

debug::fileio::FileOutput4Debug out("camera.log");

void BackgroundController::move(void) {
	background::camera::CameraInformation* camInfo;
	camInfo = background::BackgroundInterpreter::getInstance()->getCamInfo();
	// TODO : �J�����𓮂���
	char hoge[128];
	sprintf(hoge, "%G, %g, %g", camInfo->getDeltaRadX(), camInfo->getDeltaRadY(), camInfo->getDeltaRadZ());
	out.writeln(hoge);
	//cam = graphics::Camera::getInstance();
	//cam->setPosition(cam->getPositionX()+camInfo->getDeltaX(),cam->getPositionY()+camInfo->getDeltaY(),cam->getPositionZ()-camInfo->getDeltaZ());;
	//cam->addPosition(camInfo->getDeltaX(), camInfo->getDeltaY(), -camInfo->getDeltaZ());
	//cam->addRotateCamera(camInfo->getDeltaRadX(), camInfo->getDeltaRadY(), camInfo->getDeltaRadZ());
	//cam->setCamera();

	::effect::EffectInformation* effInfo;
	effInfo = interpreter->getEffInfo();
	// TODO : �G�t�F�N�g�̍X�V
	eff->fire(*effInfo);
	eff->move();

	// TODO : crntZ���[�܂ōs������z=0�t�߂ɖ߂�
	// 1����X-File��z�̋��������z����������0�ɑ������ƂŌp���ڂȂ�������͂�
	//crntZ = cam->getPositionZ();
	//if (fabs(crntZ) >= distanceZ)
	//	cam->setPosition(cam->getPositionX(), cam->getPositionY(), fabs(crntZ) - distanceZ);

	interpreter->updateCmd();
}

void BackgroundController::draw(void) {
	// X-File�̕`��
	for (UINT i = 0; i < xFiles.size(); ++i) {
		if (fabs(fabs(crntZ) - xFiles[i]->getZ()) >= 12) xFiles[i]->drawImage();
	}
	//eff->move();
	eff->draw();
}

void BackgroundController::nextState(void) {
	eff->reset();
	interpreter->nextState();
}