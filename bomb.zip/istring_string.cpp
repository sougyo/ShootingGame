#include <sstream>
#include <iostream>
#include <string>

using namespace std;

int main(void) {
	string str = "abcdefghijklmn";
	istringstream in(str);
	istringstream in2(str);
	
	string temp;
	string temp2;
	in >> temp;
	in2 >> temp2;
	
	cout << temp << endl;
	cout << temp2 << endl;
	cout << str << endl;
}