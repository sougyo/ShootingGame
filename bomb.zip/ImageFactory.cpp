#include "ImageFactory.h"

using namespace graphics;

ImageFactory::ImageFactory(void) {
}

ImageFactory::~ImageFactory(void) {
}

ImageSprite* ImageFactory::createImageSprite(const std::string& fileName) {
	return new ImageSprite(device,fileName,sprite);
}
ImageSprite* ImageFactory::createImageSprite(const char* fileName) {
	std::string file = fileName;
	return new ImageSprite(device,file,sprite);
}

Image* ImageFactory::createImage(const char* fileName) { 
	std::string file = fileName;
	return this->createImage(fileName,1.0);
}
Image* ImageFactory::createImage(const char* fileName, float alpha) { 
	std::string file = fileName;
	return this->createImage(file,alpha);
}
Image* ImageFactory::createImage(const std::string& fileName) { 
	return this->createImage(fileName,1.0);
}
Image* ImageFactory::createImage(const std::string& fileName, float alpha) { 
	if (images.find(std::string(fileName)) == images.end()) 
		images[std::string(fileName)] = new Image(device, fileName, alpha); 
	return images[std::string(fileName)];
}

ImageX* ImageFactory::createImageX(const char* fileName, float radX, float radY, float radZ,
								   float movX, float movY, float movZ) {
	std::string file = fileName;
	return this->createImageX(file,radX,radY,radZ,movX,movY,movZ);
	
}
ImageX* ImageFactory::createImageX(const std::string fileName, float radX, float radY, float radZ,
								   float movX, float movY, float movZ) {

	return new ImageX(device,fileName,radX,radY,radZ,movX,movY,movZ);
}

ImageX* ImageFactory::createImageX(background::xfile::XFileInformation* info) {
	return createImageX(info->getFileName(), info->getRadX(), info->getRadY(), info->getRadZ(), info->getX(), info->getY(), info->getZ());
}

ImageX* ImageFactory::createImageX(const char* fileName) {
	std::string file = fileName;
	return this->createImageX(file);
}
ImageX* ImageFactory::createImageX(const std::string& fileName) {
	if (imageXs.find(std::string(fileName)) == imageXs.end())
		imageXs[std::string(fileName)] = new ImageX(device, fileName);
	return imageXs[std::string(fileName)];
}

void ImageFactory::initialize(LPDIRECT3DDEVICE9& device, LPD3DXSPRITE& sprite) {
	this->device = device;
	this->sprite = sprite;
}

ImageFactory* ImageFactory::singleton = new ImageFactory();