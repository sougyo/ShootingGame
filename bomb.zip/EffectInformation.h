#ifndef ___EFFECTINFORMATION_H
#define ___EFFECTINFORMATION_H

namespace effect {
	class EffectInformation;
}

class effect::EffectInformation {
public:
	EffectInformation(void){};
	EffectInformation(int type, int strength, int frame) {
		this->type = type;
		this->strength = strength;
		this->frame = frame;
	}
	~EffectInformation(){};
private:
	double x,y,z;
	int type;
	int frame;
	int strength;
	int height;
	int other;
public:
	static const int NO_EFFECT		= -1;
	static const int RAIN			= 0;
	static const int FOG_2D			= 1;
	static const int FOG_3D			= 2;
	static const int FIRE_2D		= 3;
	static const int FIRE_3D		= 4;
	static const int WATER_2D		= 5;
	static const int WATER_3D		= 6;
	static const int LAVA			= 7;
	static const int SKY			= 8;
	static const int TORNADO		= 9;
	static const int BOSS_EFFECT	= 100;
	static const int OWN_SHIELD		= 200;
	static const int STG1			= 1001;
	static const int STG1_BOSS		= 1002;
	static const int STG2			= 1003;
	static const int STG2_BOSS		= 1004;
	static const int STG3			= 1005;
	static const int STG3_BOSS		= 1006;
	static const int STG4			= 1007;
	static const int STG4_BOSS		= 1008;
	static const int STG5			= 1009;
	static const int STG5_BOSS		= 1010;
	static const int STG6			= 1011;
	static const int STG6_BOSS		= 1012;
	static const int STG7_BOSS		= 1013;

	inline void setType(int type)			{ this->type = type;		}
	inline void setFrame(int frame)			{ this->frame = frame;		}
	inline void setStrength(int strength)	{ this->strength = strength;}
	inline void setHeight(int height)		{ this->height = height;	}
	inline void setOther(int other)			{ this->other = other;		}
	inline void setPosition(double x, double y, double z) {
		this->x = x;
		this->y = y;
		this->z = z;
	}

	inline int getType(void)	{ return type;		}
	inline int getFrame(void)	{ return frame;		}
	inline int getStrength(void){ return strength;	}
	inline int getHeight(void)	{ return height;	}
	inline int getOther(void)	{ return other;		}
	inline double getX(void)	{ return x;			}
	inline double getY(void)	{ return y;			}
	inline double getZ(void)	{ return z;			}
};

#endif	/* ___EFECTINFOMAITON_H */