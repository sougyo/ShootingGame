#ifndef ___EFFECTGROUP_H
#define ___EFFECTGROUP_H

#include <vector>
#include <string>

#include "EffectInformation.h"

namespace background {
	namespace effect {
		class EffectGroup;
	}
}

class background::effect::EffectGroup {
public:
	EffectGroup(const std::vector<const std::string>& effectList);
	~EffectGroup(void) { finalize(); }
	::effect::EffectInformation* getEffect(unsigned long crntFrame) const;
	void finalize(void);
private:
	std::vector<::effect::EffectInformation*> effectInfo;
	int frameSum;

	void analyze(const std::string& effect);
	void push(::effect::EffectInformation* info);
};

#endif	/* ___EFFECTGROUP_H */