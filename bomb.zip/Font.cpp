#include "Font.h"

using namespace font;

Font::Font(LPDIRECT3DDEVICE9 device,int x1, int y1, int x2, int y2, int height, int width, bool isLeft) {
	this->device = device;
	this->textArea.left	  = x1;
	this->textArea.right  = x2;
	this->textArea.top	  = y1;
	this->textArea.bottom = y2;
	this->isLeft		  = isLeft;

	//

	//logFont.Height          = height;
	//logFont.Width           = width;
	//logFont.Weight          = FW_NORMAL;
	//logFont.MipLevels       = 0;
	//logFont.Italic          = FALSE;
	//logFont.CharSet         = 0;
	//logFont.OutputPrecision = 0;
	//logFont.Quality         = DEFAULT_QUALITY;
	//logFont.PitchAndFamily  = DEFAULT_PITCH || FF_DONTCARE;
	//logFont.FaceName		= 
	//lstrcpy(logFont.FaceName, "");

	/*if (D3DXCreateFontIndirect(device,&logFont,&D3DFont)) {
		::MessageBox(NULL,"�t�H���g�̐ݒ�Ɏ��s���܂����B","",MB_OK);
	}*/
}
Font::Font(void) {
}

Font::~Font(void) {
	finalize();
}

void Font::finalize(void) {
	/*if (D3DFont) {
		D3DFont->Release();
		(D3DFont)=NULL;
	}*/
}

void Font::draw(std::string str) {

	//if (isLeft == true) {
	//	D3DFont->DrawText(NULL,
	//			TEXT(str.c_str()),
	//			-1,
	//			&textArea,
	//			DT_LEFT | DT_NOCLIP,
	//			D3DCOLOR_XRGB(255, 255, 255));
	//}
	//else {
	//	D3DFont->DrawText(NULL,
	//		TEXT(str.c_str()),
	//		-1,
	//		&textArea,
	//		DT_RIGHT | DT_NOCLIP,
	//		D3DCOLOR_XRGB(255, 255, 255));
	//}
}

void Font::drawWin(std::string str) {
	TextOut(hdc,10,350,str.c_str(),str.size());
}