#ifndef	___IMAGESPRITE_H
#define	___IMAGESPRITE_H

#include<d3d9.h>
#include<d3dx9.h>

#include<string>

namespace graphics {
	class ImageSprite;
}

class graphics::ImageSprite {
public:
	ImageSprite(LPDIRECT3DDEVICE9& device, const std::string& fileName, LPD3DXSPRITE& sprite);
	~ImageSprite(void);

public:
	void drawImage(double angle, int movX, int movY);
	void setTransformZ(double rad, int movX, int movY);

private:
	LPDIRECT3DTEXTURE9	texture;
	LPD3DXSPRITE		sprite;

	D3DXMATRIX matrixWorld;
	D3DXMATRIX matrixScale;
	D3DXMATRIX matrixMult;
	D3DXMATRIX matrixRad;
	D3DXMATRIX matrixMov;

	int height;
	int width;
	double centerX;
	double centerY;
	double rad;
};

#endif	/*___IMAGESPRITE_H*/