#ifndef ___XFILEINFORMATION_H
#define ___XFILEINFORMATION_H

#include <string>

namespace background {
	namespace xfile {
		class XFileInformation;
		class XFileGroup;
	}
}

class background::xfile::XFileInformation {
public:
	XFileInformation(float x, float y, float z, 
		float radX, float radY, float radZ, const std::string fileName);
	inline float getX(void) const { return x; }
	inline float getY(void) const { return y; }
	inline float getZ(void) const { return z; }
	inline float getRadX(void) const { return radX; }
	inline float getRadY(void) const { return radY; }
	inline float getRadZ(void) const { return radZ; }
	inline const std::string getFileName(void)
		const { return fileName; }
private:
	float x;
	float y;
	float z;
	float radX;
	float radY;
	float radZ;
	std::string fileName;
};

#endif	/* ___XFILEINFORMATION_H */