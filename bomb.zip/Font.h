#ifndef ___FONT_H
#define ___FONT_H

#include <d3d9.h>
#include <d3dx9.h>

#include <string>

namespace font {
	class Font;
}

class font::Font {
public:
	Font(LPDIRECT3DDEVICE9 device, int x1, int y1, int x2, int y2, int height, int width, bool isLeft);
	Font(void);
	~Font(void);

	void draw(std::string str);
	void drawWin(std::string str);
	void finalize(void);

	static Font* getInstance(void)		{ return singleton; }

private:
	LPDIRECT3DDEVICE9	device;
	LPD3DXFONT			D3DFont;
	//D3DXFONT_DESC 		logFont;
	RECT				textArea;
	bool				isLeft;

	HDC hdc;

	static Font* singleton;

};


#endif /* ___FONT_H */