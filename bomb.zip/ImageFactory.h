#ifndef ___IMAGEFACTORY_H
#define ___IMAGEFACTORY_H

#include <d3d9.h>
#include <d3dx9.h>

#include <string>
#include <map>

#include "ImageSprite.h"
#include "Image.h"
#include "ImageX.h"
#include "XFileInformation.h"

namespace graphics {
	class ImageFactory;
}

class graphics::ImageFactory {
public:
	ImageFactory();
	~ImageFactory();

public:
	void initialize(LPDIRECT3DDEVICE9& device, LPD3DXSPRITE& sprite);
	ImageSprite* createImageSprite(const std::string& fileName);
	ImageSprite* createImageSprite(const char* fileName);
	Image* createImage(const std::string& fileName);
	Image* createImage(const std::string& fileName, float alpha);
	Image* createImage(const char* fileName);
	Image* createImage(const char* fileName, float alpha);
	ImageX* createImageX(const std::string& fileName);
	ImageX* createImageX(const char* fileName);
	ImageX* createImageX(const std::string fileName, float radX, float radY, float radZ,
		float movX, float movY, float movZ);
	ImageX* createImageX(const char* fileName, float radX, float radY, float radZ,
		float movX, float movY, float movZ);
	ImageX* createImageX(background::xfile::XFileInformation* info);
	static ImageFactory* getInstance(void) { return singleton; }

private:
	LPDIRECT3DDEVICE9		device;
	LPD3DXSPRITE			sprite;
	static ImageFactory*	singleton;
	std::map<std::string, graphics::ImageSprite*> imageSprites;
	std::map<std::string, graphics::Image*> images;
	std::map<std::string, graphics::ImageX*> imageXs;
};

#endif	/*___IMAGEFACTORY_H*/