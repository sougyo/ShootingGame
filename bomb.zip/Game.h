#ifndef ___GAME_H
#define ___GAME_H

#include <cassert>
#include <ctime>
#include <string>
#include <map>

#include "HWndGameMap.h"

namespace game {
	class Game;
}

namespace graphics {
	class Graphic;
}

namespace gameinpututil {
	class DirectInput;
}

namespace gamesoundutil {
	class DirectSound;
}

namespace gamesystem {
	class GameMain;
	class NumberDisplay;
}

class game::Game {
public:
	Game(std::string gameName);
	~Game(void);
	void run(void);
	LRESULT WINAPI windowProc(UINT msg, WPARAM mainParam, LPARAM subParam);
private:
	void move(void);
	void draw(void);
private:
	HWND handle;
	HANDLE mutex;
	std::string gameName;
	double fps;
	double start;
	double finish;
	const int FPSINTERVAL;
	int time;

	graphics::Graphic* graphic;
	gameinpututil::DirectInput* input;
	gamesoundutil::DirectSound* sound;
	gamesystem::GameMain* game;
	gamesystem::NumberDisplay* numDisp;
};

#endif	/* ___GAME_H */