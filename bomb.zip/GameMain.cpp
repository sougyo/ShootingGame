#include "GameMain.h"

using namespace gamesystem;
using namespace gamestate;

GameMain::GameMain(void) : prevKeyStoreElement(static_cast<unsigned char>(0)), currentKeyStoreElement(static_cast<unsigned char>(0x08)) {
	ShootingGame::getInstance()->initializeMain();
	DisplayStateMap::getInstance()->initialize();
	gamesoundutil::DirectSound::getInstance()->setTrack(0);
	gamesoundutil::DirectSound::getInstance()->play();
	displayState = DisplayStateMap::getInstance()->getGameTitle();
	displayState->setUp();
}

GameMain::~GameMain(void) {
}

void GameMain::move(void) {
	displayState->move();
	displayState = displayState->getNextState();
}

void GameMain::draw(void) {
	displayState->draw();
}

void GameMain::setKeyData(KeyStoreElement keyStoreElement) {
	prevKeyStoreElement = currentKeyStoreElement;
	currentKeyStoreElement = keyStoreElement;
	displayState->setKeyData(currentKeyStoreElement, prevKeyStoreElement);
}