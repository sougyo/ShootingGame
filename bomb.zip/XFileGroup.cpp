#include "XFileGroup.h"

using namespace background::xfile;

#include "StringUtil.h"
#include "gameMath.h"

XFileGroup::XFileGroup(const std::vector<const std::string>& xfileList) {
	for (unsigned int i = 0; i < xfileList.size(); i++)
		analyze(xfileList[i]);
	index = xfileInfo.size();
}

void XFileGroup::finalize(void) {
	for (unsigned int i = 0; i < xfileInfo.size(); ++i) {
		delete xfileInfo.at(i);
	}
	xfileInfo.clear();
}

void XFileGroup::analyze(const std::string& xfile) {
	using lang::util::StringUtil;
	std::string fileName = StringUtil::substring(xfile, 0, StringUtil::indexOf(xfile, ' '));
	fileName = StringUtil::addStr(fileName, ".x", true);
	std::string args = StringUtil::substring(xfile, fileName.length() + 1, xfile.length());
	float x, y, z, radX, radY, radZ;
	int index = 0;
	x = StringUtil::toFloat(getArg(args, index++));
	y = StringUtil::toFloat(getArg(args, index++));
	z = StringUtil::toFloat(getArg(args, index++));
	radX = toFloat(getArg(args, index++));
	radY = toFloat(getArg(args, index++));
	radZ = toFloat(getArg(args, index++));
	push(new XFileInformation(x, y, z, radX, radY, radZ, fileName));
}

float XFileGroup::toFloat(std::string str) const {
	using gamemath::toRadian;
	using lang::util::StringUtil;
	return static_cast<float>(toRadian(StringUtil::toDouble(str)));
}

std::string XFileGroup::getArg(const std::string args, int count) {
	size_t start = 0;
	size_t end = args.find(",", 0);
	for (int i = 0; i < count; i++) {
		start = end + 1;
		end = args.find(",", start);
	}
	return lang::util::StringUtil::substring(args, start, end);
}

void XFileGroup::push(XFileInformation* info) {
	xfileInfo.push_back(info);
}