#include "XFileInformation.h"

using namespace background::xfile;

XFileInformation::XFileInformation(float x, float y, float z,
		float radX, float radY, float radZ, const std::string fileName) {
	this->x = x;
	this->y = y;
	this->z = z;
	this->radX = radX;
	this->radY = radY;
	this->radZ = radZ;
	this->fileName = fileName;
}