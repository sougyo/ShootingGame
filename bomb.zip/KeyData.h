#ifndef __KEYDATA_H
#define __KEYDATA_H

namespace gameinpututil {
    class KeyData;
}

class gameinpututil::KeyData {
private:
    bool up;
    bool down;

    bool left;
    bool right;

    bool shot;
    bool bomb;
    bool slow;
    bool skip;
    bool pause;

public:
	KeyData(void);

    inline void setUp(bool up) { this->up = up; }
    inline bool isUp(void) const { return up; }
    inline void setDown(bool down) { this->down = down; }
    inline bool isDown(void) const { return down; }
    inline void setLeft(bool left) { this->left = left; }
    inline bool isLeft(void) const { return left; }
    inline void setRight(bool right) { this->right = right; }
    inline bool isRight(void) const { return right; }

    inline void setShot(bool shot) { this->shot = shot; }
    inline bool isShot(void) const { return shot; }
    inline void setBomb(bool bomb) { this->bomb = bomb; }
    inline bool isBomb(void) const { return bomb; }
    inline void setSlow(bool slow) { this->slow = slow; }
    inline bool isSlow(void) const { return slow; }
    inline void setSkip(bool skip) { this->skip = skip; }
    inline bool isSkip(void) const { return skip; }
    inline void setPause(bool pause) { this->pause = pause; }
    inline bool isPause(void) const { return pause; }

};

#endif // __KEYDATA_H
