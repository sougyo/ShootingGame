#ifndef ___SCENE3D_H
#define ___SCENE3D_H

#include<d3d9.h>
#include<d3dx9.h>

namespace graphics {
	class Scene3D;
}

class graphics::Scene3D() {
public:
	Scene3D();
	~Scene3D();

public:
	HRESULT Create(LPDIRECT3DDEVICE9 device);
};

#endif	/*___SCENE3D_H*/