#ifndef ___CAMERA_H
#define ___CAMERA_H

#include<d3d9.h>
#include<d3dx9.h>

namespace graphics {
	class Camera;
}

class graphics::Camera {
private:
	Camera(void);
public:
	~Camera();

private:
	void rotateCamera(void);
	void updateVelocity(void);
public:
	void initialize(LPDIRECT3DDEVICE9& device);
	void setCamera(void);
	void setAllCamera(float angleX, float angleY, float angleZ, float movX, float movY, float movZ);
	void resetCamera(void);

	void setVelocity(float vX, float vY, float vZ);
	void addVelocity(float vX, float vY, float vZ);

	void setPosition(float movX, float movY, float movZ);
	void addPosition(float movX, float movY, float movZ);

	void setRotateCamera(float angleX, float angleY, float angleZ);
	void addRotateCamera(float angleX, float angleY, float angleZ);

	void setVelocityRotateCamera(float vangleX, float vangleY, float vangleZ);
	void addRotateCameraRad(float radX, float radY, float radZ);

	inline float getPositionX(void)		{ return x;		};
	inline float getPositionY(void)		{ return y;		};
	inline float getPositionZ(void)		{ return z;		};

	inline float getAngleX(void)			{ return angleX;};
	inline float getAngleY(void)			{ return angleY;};
	inline float getAngleZ(void)			{ return angleZ;};

	inline float getRadX(void)				{ return radX;	};
	inline float getRadY(void)				{ return radY;	};
	inline float getRadZ(void)				{ return radZ;	};

	static Camera* getInstance(void)		{ return singleton; };

private:
	LPDIRECT3DDEVICE9	device;

	D3DXMATRIX	projection;		// �J�����̉�p�Ȃ�
	D3DXMATRIX	matrixView;		// �J�����̔z�u

	D3DXMATRIX	matrixWorld;	// �J�����}�g���b�N�X
	D3DXMATRIX	matrixRad;		// �J�����̉�]�p�x
	D3DXMATRIX	matrixMov;		// �J�����̈ړ�

	float		angleX,angleY,angleZ;
	float		radX,radY,radZ;
	float		x,y,z;
	float		vX,vY,vZ;
	float		vangleX,vangleY,vangleZ;

	static Camera* singleton;
};

#endif	/*___Camera_H*/