#ifndef __DIRECTSOUND_H
#define __DIRECTSOUND_H

// �v���p�e�B�������J�����́��ǉ��̈ˑ��t�@�C�� �� winmm.lib ��ǉ����邱��
// BGM�ESE �̃t�@�C�������݂��Ȃ��ꍇ�͋����I�������iDirectSound�����̐݌v�j
// BGM�ESE �̃t�@�C���p�X�͂��ꂼ��A
// .\BGM\BGM_00.wav, .\BGM\BGM_01.wav,�E�E�E�A.\SE\SE_00.wav, .\SE\SE_01.wav,�E�E�E�Ƃ��邱��

// TODO: ���[�v�̎���

#include <dsound.h>
#include <windows.h>
#include <string>
#include <vector>
#include "./DirectSoundFile/DXUTsound.h"
#include "DirectXUtil.h"

namespace gamesoundutil {
	using directsoundutil::CSoundManager;
	using directsoundutil::CSound;
	using directsoundutil::CStreamingSound;

	class DirectSound;
}

class gamesoundutil::DirectSound {
private:
	static DirectSound* directSoundSingleton;

	static const int CHANNELS = 2; // channel
	static const int SAMPLINGRATE = 44100; // Hz
	static const int BITRATE = 16; // bps
    static const int OVERLAPNUM = 10; // SE�����Đ���
    static const LONG VOLUMEINTERVAL = 250; // ���ʒ��ߒP��

	int BGM_NUM;
	int NSE_NUM;
	int GSE_NUM;

	std::vector<std::vector<std::string> > musicInfo;

	std::string* trackNamesBGM;
	std::string* trackNamesSE;

	unsigned int trackNum;
    unsigned int prevTrackNum;
    bool* isGameSEPausing_;

    bool isPausing_;

    LONG volumeBGM;
    LONG volumeSE;

	CSoundManager* soundManager;

	CSound* soundBGM;

	CSound** soundNormalSE;
	CSound** soundGameSE;

	LPDIRECTSOUNDBUFFER primaryBuffer;

	DirectSound(void);

	DirectSound(const DirectSound&);
	DirectSound& operator = (const DirectSound&);
	~DirectSound(void);

	bool initFileName(void);
	void initSE(void);

public:
	static DirectSound* getInstance(void) { return directSoundSingleton; }

	bool initInstance(HWND wndApp);

	bool setTrack(int trackNum);
    int getNextTrack(void);

	bool play(void);
	bool pause(void);
	bool stop(void);

	bool playNormalSE(int trackNum);
	bool playGameSE(int trackNum);

	bool isBGMPlaying(void) const;
	bool isNormalSEPlaying(int trackNum) const;
	bool isGameSEPlaying(int trackNum) const;

    bool incBGMVolume(void);
    bool decBGMVolume(void);
    bool incSEVolume(void);
    bool decSEVolume(void);
    void resetVolume(void);

    inline bool isPausing(void) const { return isPausing_; }
	inline int getTrackNum(void) const { return trackNum; }
	inline int getBGMVolume(void) const { return (volumeBGM - DSBVOLUME_MIN / 2) * 2 / 100; }
    inline int getSEVolume(void) const { return (volumeSE - DSBVOLUME_MIN / 2) * 2 / 100; }

	inline std::string getTrackName(void) const {
		if (soundBGM == 0) return "NoName";
		else return musicInfo[trackNum][1];
	}
	inline std::string getTrackInfo(void) const {
		if (soundBGM == 0) return "NoInfo";
		else return musicInfo[trackNum][2];
	}
   	inline std::string getTrackName(int trackNum) const {
		if (soundBGM == 0) return "NoName";
		else return musicInfo[trackNum][1];
	}
	inline std::string getTrackInfo(int trackNum) const {
		if (soundBGM == 0) return "NoInfo";
		else return musicInfo[trackNum][2];
	}
};

#endif // __DIRECTSOUND_H