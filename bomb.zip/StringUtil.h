#ifndef ___STRINGUTIL_H
#define ___STRINGUTIL_H

#include <string>

namespace lang {
	namespace util {
		class StringUtil;
	}
}

class lang::util::StringUtil {
public:
	static std::string substring(const std::string& str, size_t start, size_t end);
	static int indexOf(const std::string& str, char ch);
	static int indexOf(const std::string& src, const std::string& str);
	static std::string trim(const std::string& str);
	static bool isWhiteSpace(char ch);
	static bool isLineNew(char ch);
	static bool equals(const std::string& str1, const std::string& str2);
	static int toInteger(const std::string& str);
	static long toLong(const std::string& str);
	static double toDouble(const std::string& str);
	static float toFloat(const std::string& str);
	static bool startsWith(const std::string& src, const std::string& str);
	static bool endsWith(const std::string& src, const std::string& str);
	static std::string addStr(const std::string& origin, const std::string& def, bool isCheck=false);
private:
	StringUtil(void);
	StringUtil(const StringUtil&);
	StringUtil& operator=(const StringUtil&);
};

#endif	/* ___STRINGUTIL_H */