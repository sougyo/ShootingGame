#ifndef	___IMAGE3D_H
#define	___IMAGE3D_H

#include<d3d9.h>
#include<d3dx9.h>

namespace graphics {
	class Image3D;
}

class graphics::Image3D {
public:
	Image3D(LPDIRECT3DDEVICE9& device, char* fileName);
	~Image3D(void);

public:
	void drawImage(double angle, int movX, int movY);
	void setTransformZ(double rad, int movX, int movY);

private:
	LPDIRECT3DDEVICE9	device;
	LPDIRECT3DTEXTURE9	texture;

	D3DXMATRIX matrixRad;
	D3DXMATRIX matrixMov;

	double rad;

	D3DXMATRIX	matrixWorld;	// ���f���̔z�u

	// VertexBuffer
	LPDIRECT3DVERTEXBUFFER9		vertexBuffer;

	// ���_�P�̃f�[�^�^
	struct MY_VERTEX{
		D3DXVECTOR3 position;	// �ʒu
		DWORD		color;		// �F
		D3DXVECTOR2 texture;	// �e�N�X�`���[�̉摜�̈ʒu
	};

	MY_VERTEX* v;

	// �e�u�e�̐ݒ�
	#define MY_VERTEX_FVF  (D3DFVF_XYZ | D3DFVF_DIFFUSE  | D3DFVF_TEX1)
};

#endif	/*___IMAGE3D_H*/