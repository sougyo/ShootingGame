#ifndef ___COMMANDGROUPS_H
#define ___COMMANDGROUPS_H

#include "CommandGroup.h"
#include "FileOutput4Debug.h"

namespace background {
	namespace command {
		class CommandGroups;
	}
}
#include <iostream>
class background::command::CommandGroups {
public:
	CommandGroups(CommandGroup* cmd, unsigned int frame) {
		this->cmd = cmd;
		this->frame = frame;
	}
	~CommandGroups(void) { finalize(); }
	inline void finalize(void) { cmd->finalize(); delete cmd; }
	inline unsigned int getFrame(void) const { return frame; }
	inline CommandGroup* getCommandGroup(void) const {  return cmd; }
private:
	CommandGroup* cmd;
	unsigned int frame;
};

#endif	/* ___COMMANDGROUPS_H */