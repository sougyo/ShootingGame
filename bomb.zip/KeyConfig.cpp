#include "KeyConfig.h"

using namespace gameinpututil;

#include <fstream>

KeyConfig::KeyConfig(void) {
}

KeyConfig::~KeyConfig(void) {
}

void KeyConfig::initInstance(DirectInput* directInput) {
	this->directInput = directInput;

	// TODO: �t�@�C���ǂݍ���
	std::ifstream in("config.cfg", std::ios::binary);

	if (!in) {
        resetKey();
	}
	else {
		in.read((char*)(&joypadPushKeys), sizeof(joypadPushKeys));
		in.close();

	    setKey();
	}

}

void KeyConfig::setJoypadPushedKey(Button buttonNum) {
	DWORD button = directInput->getPushedKey();

	for (int i = 0; i < BUTTONNUM; i++)
		if (joypadPushKeys[i] == button) {
			joypadPushKeys[i] = joypadPushKeys[buttonNum];
			break;
		}

	joypadPushKeys[buttonNum] = button;
}

void KeyConfig::resetKey(void) {    
	for (int i = 0; i < BUTTONNUM ; i++)
		joypadPushKeys[i] = DIJOFS_BUTTON(i);

	setKey();
}

void KeyConfig::end(void) {
	std::ofstream out("config.cfg", std::ios::binary);
	out.write((char*)(&joypadPushKeys), sizeof(joypadPushKeys));
	out.close();
}

Button KeyConfig::getButton(int num) {
	switch (num) {
		case Shot: return Shot;
		case Bomb: return Bomb;
		case Slow: return Slow;
		case Skip: return Skip;
		case Pause: return Pause;

		default: return Shot;
	}
}

KeyConfig* KeyConfig::keyConfigSingleton = new KeyConfig();
